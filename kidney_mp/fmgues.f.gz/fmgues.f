	PROGRAM FMGUES
C TO REACH INTO VASCULAR BOUND.TEM FILES TO GENERATE GUESS.DAT FILE FOR KIDNEY
C
	INTEGER SOLS,SLICE
C
C PARAMETERS
	DOUBLE PRECISION
     1   Z(15),DT,PKC,PKP,PKN,PKF
C 
C VARIABLES
	DOUBLE PRECISION
     1   VC(21),PC(21),CC(31,21),IMPC(21),LCHC(21),
     1   VS(21),PS(21),CS(16,21),IMPS(21),LCHS(21),
     1   FVC(21),HCTC(21)
C
	DOUBLE PRECISION RJ,TPS,TNS,TFS,QPS,QNS,QFS
C
	OPEN (UNIT=242,FILE='vasc/mrdvr/mrdbound.tem')
	OPEN (UNIT=202,FILE='vasc/omdvr/omdbound.tem')
	OPEN (UNIT=222,FILE='vasc/imdvr/imdbound.tem')
        OPEN (301,FILE='kguess.dat')
C
C  SOLUTE INDEX:
C	1-	NA+
C	2-	K+
C	3-	CL-
C	4-	HCO3-
C	5-	H2CO3
C	6-	CO2
C	7-	HPO4--
C	8-	H2PO4-
C	9-	UREA
C	10-	NH3
C	11-	NH4+
C	12-	H+
C	13-	HCO2-
C	14-	H2CO2
C	15-	GLUC
C
	Z(1)=1.D0
	Z(2)=1.D0
	Z(3)=-1.D0
	Z(4)=-1.D0
	Z(5)=0.D0
	Z(6)=0.D0
	Z(7)=-2.D0
	Z(8)=-1.D0
	Z(9)=0.D0
	Z(10)=0.D0
	Z(11)=1.D0
	Z(12)=1.D0
	Z(13)=-1.D0
	Z(14)=0.D0
	Z(15)=0.D0
C
	PKC=3.57
	PKF=3.76
	PKP=6.8
	PKN=9.15
        SOLS=15
        SLICE=10
C
C READ THE GUESSES AT THE SLICE LEVELS: MR(1-2), OM(3-5), IM(5-10)
C  OM(3) is the IS guess at CMJ, between PCT and PST, while
C  MR(2) is the IS guess at MRMJ, between AHLc and AHLm (or at proximal OMCD)
C  Common OM IS is assumed for OM(4) and OM(5)
C  OM(5) and IM(5) are identical
C
C MR
	READ(242,50) DT,FVC(1),HCTC(1),
     1  VC(1),VS(1),VS(2),
     1  PC(1),PS(1),PS(2),
     1  CC(16,1),CS(16,1),CS(16,2),
     1  (CC(I,1),CS(I,1),CS(I,2),I=1,11),
     1  (CC(I,1),CS(I,1),CS(I,2),I=13,15)
   50   FORMAT (2D12.4,F8.4,/,3F8.4,/,3F8.4,/,3F8.4,/,(3F14.9))
C
	READ(202,50) DT,FVC(3),HCTC(3),
     1  VC(3),VS(3),VS(5),
     1  PC(3),PS(3),PS(5),
     1  CC(16,3),CS(16,3),CS(16,5),
     1  (CC(I,3),CS(I,3),CS(I,5),I=1,11),
     1  (CC(I,3),CS(I,3),CS(I,5),I=13,15)
C
C OM
	J=4
	RJ=0.5
	VS(J)=0.D0
	PS(J)=(1.D0-RJ)*PS(3) + RJ*PS(5)
	CS(16,J)=(1.D0-RJ)*CS(16,3) + RJ*CS(16,5)
	DO 52 I=1,SOLS
   52   CS(I,J)=(1.-RJ)*CS(I,3) + RJ*CS(I,5)
	LCHS(J)=PKC + DLOG10(CS(4,J)/CS(5,J))
	CS(12,J)=10.**(-LCHS(J))
C
	TPS=CS(7,J)+CS(8,J)
	TNS=CS(10,J)+CS(11,J)
	TFS=CS(13,J)+CS(14,J)
C
	QPS=10.**(LCHS(J)-PKP)
	QNS=10.**(LCHS(J)-PKN)
	QFS=10.**(LCHS(J)-PKF)
C
	CS(8,J)=TPS/(1.+QPS)
	CS(7,J)=TPS-CS(8,J)
	CS(11,J)=TNS/(1.+QNS)
	CS(10,J)=TNS-CS(11,J)
	CS(14,J)=TFS/(1.+QFS)
	CS(13,J)=TFS-CS(14,J)
C
	CS(3,J)= CS(1,J)*Z(1) + CS(2,J)*Z(2)
	DO 53 I=4,SOLS
   53   CS(3,J)=CS(3,J)+CS(I,J)*Z(I)
C
C IM
	READ(222,50) DT,FVC(5),HCTC(5),
     1  VC(5),VS(5),VS(10),
     1  PC(5),PS(5),PS(10),
     1  CC(16,5),CS(16,5),CS(16,10),
     1  (CC(I,5),CS(I,5),CS(I,10),I=1,11),
     1  (CC(I,5),CS(I,5),CS(I,10),I=13,15)
C
	DO 64 J=6,9
	RJ=DBLE(0.2*FLOAT(J-5))
	VS(J)=0.D0
	PS(J)=(1.D0-RJ)*PS(5) + RJ*PS(10)
	CS(16,J)=(1.D0-RJ)*CS(16,5) + RJ*CS(16,10)
	DO 62 I=1,SOLS
   62   CS(I,J)=(1.-RJ)*CS(I,5) + RJ*CS(I,10)
	LCHS(J)=PKC + DLOG10(CS(4,J)/CS(5,J))
	CS(12,J)=10.**(-LCHS(J))
C
	TPS=CS(7,J)+CS(8,J)
	TNS=CS(10,J)+CS(11,J)
	TFS=CS(13,J)+CS(14,J)
C
	QPS=10.**(LCHS(J)-PKP)
	QNS=10.**(LCHS(J)-PKN)
	QFS=10.**(LCHS(J)-PKF)
C
	CS(8,J)=TPS/(1.+QPS)
	CS(7,J)=TPS-CS(8,J)
	CS(11,J)=TNS/(1.+QNS)
	CS(10,J)=TNS-CS(11,J)
	CS(14,J)=TFS/(1.+QFS)
	CS(13,J)=TFS-CS(14,J)
C
	CS(3,J)= CS(1,J)*Z(1) + CS(2,J)*Z(2)
	DO 63 I=4,SOLS
   63   CS(3,J)=CS(3,J)+CS(I,J)*Z(I)
   64   CONTINUE
C
        WRITE (301,28) (PS(K),K=1,SLICE)
        DO 22 J=1,11
   22   WRITE (301,28) (CS(J,K),K=1,SLICE)
        DO 24 J=13,15
   24   WRITE (301,28) (CS(J,K),K=1,SLICE)
   28   FORMAT(10D16.8)
C
        STOP
        END
