        PROGRAM GRCR
C
C  Program to read the interstitial variables, compute the proton concentrations,
C   and check that all of the buffer pairs yield consistent pH.
C  Output is to be suitable for graphing
C
C LOCAL VARIABLES
C
	INTEGER SOLS,
     1    CHOP,OMCHOP,IMCHOP,MRCHOP,
     1    SLICE,OMSLC,IMSLC,MRSLC
C
C	CHOP-	SPATIAL CHOP OF TUBULE
C       OMCHOP,IMCHOP,MRCHOP - REGIONAL CHOP FOR OM, IM AND MR
C       SLICE-  OM+IM+MR DISCRETIZATION OF GUESSES 
C               (REFINED TO OMCHOP+IMCHOP+MRCHOP BY LINEAR INTERPOLATION)
C               GAMMA VECTOR IS BASED ON SLICE
C
	INTEGER ISEG,NN(25)
C
C GENERAL PARAMETERS
	DOUBLE PRECISION
     1   Z(15),PKC,PKF,PKN,PKP,
     1   LCHS(91),TPS,TNS,TFS,QPS,QNS,QFS
C
C SPECIFIED BOUNDARY DATA
C
        DOUBLE PRECISION
     1   CSMR(15,201,2),CSOM(15,101,2),CSIM(15,501,2),
     1   PSMR(201,2),PSOM(101,2),PSIM(501,2),
     1   CSGAM(15,91),PSGAM(91),KEPSI,
     1   PS0(3),IMPM0(2),IMPS0(3),CM0(15,2),CS0(16,3), 
     1   FVC0(4),PC0(3),IMPC0(3),HCT0(3),CC0(16,3)
C
C       CSMR,CSOM,CSIM- CS CONCENTRATIONS AT GRID POINTS (FOR EXPORT TO NEPHRON AND VASC)
C       PSMR,PSOM,PSIM- PS VALUES AT GRID POINTS (FOR EXPORT TO NEPHRON AND VASC)
C       CSGAM-  GUESS CS CONCENTRATIONS AT SLICE BOUNDARIES
C       PSGAM-  GUESS PS VALUES AT SLICE BOUNDARIES
C       KEPSI-   ERROR TOLERANCE FOR THE KIDNEY ITERATIONS
C
C	FVMO(1) and FVM0(2)- SFPCT and JMPCT(2) flows for all SF and JM(2) nephrons
C	PSO- 	SFPCT, JMPCT, and DCT/CNT vascular pressures (uniform)
C	IMPM0- filtered impermeant osmolality
C	IMPS0- vascular impermeant osmolality for SFPCT, JMPCT, and DCT/CNT (mM)
C	CM0-	glomerular filtrate composition
C	CS0-	vascular plasma composition for SFPCT, JMPCT, and DCT/CNT
C	CSMR-	cortical composition within medullary ray
C
C	FVC0-	capillary plasma flow for individual OMDVR, OIDVR, and MRDVR
C	PC0-	capillary pressures
C	IMPC0- 	capillary protein concentration (gm/dl)
C	HCT0-	hematocrits
C	CC0-	capillary solute composition
C
C Parameters specific to GRCR
C
        CHARACTER*5 SWG,SWPR,SWPH,VNAME
        INTEGER KSOL(20)
        DOUBLE PRECISION X(100),VAROUT(100,20),
     1  MRDIST,OMDIST,IMDIST,MRDX,OMDX,IMDX
C
C       SWG-    ABCISSA CHOICE:FROM MR->IM OR OM->IM (mrim or omim)
C       X-      ABCISSA 
C       MRDIST,OMDIST,IMDIST-   THICKNESS OF THE REPSECTIVE SEGMENT
C       MRDX,OMDX,IMDX-         THICKNESS OF EACH SECTION
C       VAROUT- OUTPUT VARIABLES
C
C FOR THE BASELINE CONFIRGURATION:
C  SLICE DEMARCATIONS AT 0 - 7 MM FROM OM TO PAPILLA
C  THE INITIAL POINT AT 0 MM CORRESPONDS TO A SINGLE MR SLICE, 2MM IN THICKNESS
C Interstitial unknows are pressure and concentration at 2 points in OM, 5 points
C  in IM, and one point in MR.  The x=0 point in OM abuts PST; there is a second
c  x=0 point in OM that is identified with MR=2mm, and this abuts AHL and OMCD.
C The points MR(1) and OM(1) will be assigned cortical concentrations, so there
C  are a total of 8 sets of IS unknowns.
C
C                                       MR(1)
C
C                                       MR(2)
C                _____________________________________ (continuity MR->OM)
C                        OM(1)          MR(2)
C                             \        /
C                             OM(2)=MR(3)
C                             OM(3)=MR(4)
C                _____________________________________ (continuity OM->IM)
C                                OM(3)
C                                IM(1)
C                                 ...
C                                IM(5)
C
C (9/16/18) With the introduction of finer chop, we will still continue to insist on a 
C  well-stirred OM, without distinguishing special MR comparment within OM.  The rationale
C  is that the Layton observations is that such differences are small.
C
	NTUB=6
C
C  SOLUTE INDEX:
C	1-	NA+
C	2-	K+
C	3-	CL-
C	4-	HCO3-
C	5-	H2CO3
C	6-	CO2
C	7-	HPO4--
C	8-	H2PO4-
C	9-	UREA
C	10-	NH3
C	11-	NH4+
C	12-	H+
C	13-	HCO2-
C	14-	H2CO2
C	15-	GLUC
C
        OPEN (301,FILE='kguess.new')
        OPEN (302,FILE='xy.kguess')
C
	Z(1)=1.D0
	Z(2)=1.D0
	Z(3)=-1.D0
	Z(4)=-1.D0
	Z(5)=0.D0
	Z(6)=0.D0
	Z(7)=-2.D0
	Z(8)=-1.D0
	Z(9)=0.D0
	Z(10)=0.D0
	Z(11)=1.D0
	Z(12)=1.D0
	Z(13)=-1.D0
	Z(14)=0.D0
	Z(15)=0.D0
C
	PKC=3.57
	PKF=3.76
	PKP=6.8
	PKN=9.15
        SOLS=15
C
        PRINT 42
   42   FORMAT(' MRSLC= ',$)
        READ *, MRSLC
        PRINT 44
   44   FORMAT(' OMSLC= ',$)
        READ *, OMSLC
        PRINT 46
   46   FORMAT(' IMSLC= ',$)
        READ *, IMSLC
	SLICE = OMSLC+IMSLC+MRSLC
C
   47   PRINT 48
   48   FORMAT(' OUTPUT SLICES: MR->IM (mrim) or OM->IM (omim): ',$)
        READ *, SWG
        IF((SWG.NE.'mrim').AND.(SWG.NE.'omim')) THEN
        PRINT 49
   49   FORMAT(' NOT A VALID SWG CHOICE. TRY AGAIN.')
        GO TO 47
        ELSE
        ENDIF
C
        MRDIST=0.2
        MRDX=MRDIST/FLOAT(MRSLC)
        OMDIST=0.2
        OMDX=OMDIST/FLOAT(OMSLC)
        IMDIST=0.5
        IMDX=IMDIST/FLOAT(IMSLC)
C
        X(MRSLC+1)=0.D0
        DO 12 I=1,MRSLC
   12   X(MRSLC+1-I)=X(MRSLC+2-I)-MRDX
        DO 14 I=1,OMSLC
   14   X(MRSLC+1+I)=X(MRSLC+I)+OMDX
        DO 16 I=1,IMSLC
   16   X(MRSLC+OMSLC+1+I)=X(MRSLC+OMSLC+I)+IMDX
C
C The pressures and solute are read in, first MR and then OM -> IM.
C
        READ (301,28) (PSGAM(K),K=1,SLICE+2)
        DO 22 J=1,11
   22   READ (301,28) (CSGAM(J,K),K=1,SLICE+2)
        DO 24 J=13,15
   24   READ (301,28) (CSGAM(J,K),K=1,SLICE+2)
   28   FORMAT(5D30.20)
C
        DO 34 K=1,SLICE+2
	LCHS(K)=PKC + DLOG10(CSGAM(4,K)/CSGAM(5,K))
	CSGAM(12,K)=10.**(-LCHS(K))
C
	TPS=CSGAM(7,K)+CSGAM(8,K)
	TNS=CSGAM(10,K)+CSGAM(11,K)
	TFS=CSGAM(13,K)+CSGAM(14,K)
C
	QPS=10.**(LCHS(K)-PKP)
	QNS=10.**(LCHS(K)-PKN)
	QFS=10.**(LCHS(K)-PKF)
C
	CSGAM(8,K)=TPS/(1.+QPS)
	CSGAM(7,K)=TPS-CSGAM(8,K)
	CSGAM(11,K)=TNS/(1.+QNS)
	CSGAM(10,K)=TNS-CSGAM(11,K)
	CSGAM(14,K)=TFS/(1.+QFS)
	CSGAM(13,K)=TFS-CSGAM(14,K)
C
	CSGAM(3,K)= CSGAM(1,K)*Z(1) + CSGAM(2,K)*Z(2)
	DO 33 I=4,SOLS
   33   CSGAM(3,K)=CSGAM(3,K)+CSGAM(I,K)*Z(I)
   34   CONTINUE
C
        NCOLS=1
        PRINT 50
   50   FORMAT(' IS PRESSURE A VARIABLE? (y,n): ',$)
        READ *, SWPR
        IF(SWPR.EQ.'y') NCOLS=NCOLS+1
C
        PRINT 60
   60   FORMAT(' HOW MANY SOLUTES? ',$)
        READ *, NSOL
        NCOLS=NCOLS+NSOL
C
        IF (NSOL.EQ.0) THEN 
        GO TO 70
        ELSE IF (NSOL.EQ.SOLS) THEN
        DO 62 ISOL=1,SOLS
   62   KSOL(ISOL)=ISOL
        ELSE
   63   DO 68 ISOL=1,NSOL
        PRINT 64, ISOL
   64   FORMAT(' SPECIES #',I2,' = ',$)
        READ *, VNAME
C
	IF(VNAME.EQ.'na') THEN
	 KSOL(ISOL)=1
	ELSE IF(VNAME.EQ.'k') THEN
	 KSOL(ISOL)=2
	ELSE IF(VNAME.EQ.'cl') THEN
	 KSOL(ISOL)=3
	ELSE IF(VNAME.EQ.'hco3') THEN
	 KSOL(ISOL)=4
	ELSE IF(VNAME.EQ.'h2co3') THEN
	 KSOL(ISOL)=5
	ELSE IF(VNAME.EQ.'co2') THEN
	 KSOL(ISOL)=6
	ELSE IF(VNAME.EQ.'hpo4') THEN
	 KSOL(ISOL)=7
	ELSE IF(VNAME.EQ.'h2po4') THEN
	 KSOL(ISOL)=8
	ELSE IF(VNAME.EQ.'urea') THEN
	 KSOL(ISOL)=9
	ELSE IF(VNAME.EQ.'nh3') THEN
	 KSOL(ISOL)=10
	ELSE IF(VNAME.EQ.'nh4') THEN
	 KSOL(ISOL)=11
	ELSE IF(VNAME.EQ.'h') THEN
	 KSOL(ISOL)=12
	ELSE IF(VNAME.EQ.'hco2') THEN
	 KSOL(ISOL)=13
	ELSE IF(VNAME.EQ.'h2co2') THEN
	 KSOL(ISOL)=14
	ELSE IF(VNAME.EQ.'gluc') THEN
	 KSOL(ISOL)=15
	ELSE
	PRINT 65
   65   FORMAT (' NO SUCH SPECIES, TRY AGAIN')
	GO TO 63
	ENDIF
C
   68   CONTINUE
        ENDIF
C
   70   CONTINUE
        PRINT 72
   72   FORMAT(' IS PH A VARIABLE? (y,n): ',$)
        READ *, SWPH
        IF(SWPH.EQ.'y') NCOLS=NCOLS+1
C
C  Load the output matrix
C
        IF(SWG.EQ.'mrim') GO TO 90
C
C This is the OM->IM case.
C
        NROWS=OMSLC+IMSLC+1
        DO 88 I=1,NROWS
        VAROUT(I,1)=X(MRSLC+I)
        IF(NSOL.EQ.0) GO TO 83
        DO 82 J=1,NSOL
   82   VAROUT(I,1+J)=CSGAM(KSOL(J),MRSLC+1+I)
C
   83   JCOL=1+NSOL
        IF(SWPR.EQ.'y') THEN
        VAROUT(I,1+JCOL)=PSGAM(MRSLC+1+I)
        JCOL=2+NSOL
        ELSE
        ENDIF
C
        IF(SWPH.EQ.'y') THEN
        VAROUT(I,1+JCOL)=LCHS(MRSLC+1+I)
        ELSE
        ENDIF
   88   CONTINUE
        GOTO 100
C
C This is the MR->IM case.
C
   90   NROWS=SLICE+1
        DO 95 I=1,MRSLC+1
        VAROUT(I,1)=X(I)
        IF(NSOL.EQ.0) GO TO 93
        DO 92 J=1,NSOL
   92   VAROUT(I,1+J)=CSGAM(KSOL(J),I)
C
   93   JCOL=1+NSOL
        IF(SWPR.EQ.'y') THEN
        VAROUT(I,1+JCOL)=PSGAM(I)
        JCOL=2+NSOL
        ELSE
        ENDIF
C
        IF(SWPH.EQ.'y') THEN
        VAROUT(I,1+JCOL)=LCHS(I)
        ELSE
        ENDIF
   95   CONTINUE
C
        DO 99 I=MRSLC+2,SLICE+1
        VAROUT(I,1)=X(I)
        IF(NSOL.EQ.0) GO TO 97
        DO 96 J=1,NSOL
   96   VAROUT(I,1+J)=CSGAM(KSOL(J),1+I)
C
   97   JCOL=1+NSOL
        IF(SWPR.EQ.'y') THEN
        VAROUT(I,1+JCOL)=PSGAM(1+I)
        JCOL=2+NSOL
        ELSE
        ENDIF
C
        IF(SWPH.EQ.'y') THEN
        VAROUT(I,1+JCOL)=LCHS(1+I)
        ELSE
        ENDIF
   99   CONTINUE
C
  100   DO 102 I=1,NROWS
C  102   WRITE(302,101) (VAROUT(I,J),J=1,NCOLS)
  102   WRITE(302,101) 1.D1*VAROUT(I,1),(1.D3*VAROUT(I,J),J=2,NCOLS)
  101   FORMAT(8E16.8)
C
        STOP
        END
