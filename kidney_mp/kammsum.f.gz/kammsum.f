	SUBROUTINE KAMMSUM(TGPHI,PHI,
     1   FVM0,AFVM,DFVM,AFVM0,DFVM0,MDCL,DMDCL,DNR,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0,
     1   OMDIST,IMDIST,MRDIST,OMJVMS,OMJKMS,IMJVMS,IMJKMS,
     1   MRJVMS,MRJKMS,MEDJVMS,MEDJKMS,SEGV,SEGK,OMJVCS,OMJKCS,
     1   IMJVCS,IMJKCS,MRJVCS,MRJKCS,MEDJVCS,MEDJKCS,VSEGV,VSEGK)
C
C  Output program to tablulate ammonia fluxes within the 3 regions: Cortex, MR, and Medulla
C   Table format - volume (muL/min) and ammonia fluxes (nmol/min): entry, exit, net
C     Cortex - Cap, SFPCT+JMPCT, SFDCT+JMDCT, CNT, nephron sum
C     MR - Cap, SFPST, SFAHLc+JMAHLc, CCD, nephron sum
C     Medulla - Cap, SFPST+JMPST, SFAHLm+JMAHLm, MCD, nephron sum
C     Whole kidney ammonia - vessels, nephrons, generation
C
C LOCAL VARIABLES
C
	INTEGER SWG,SOLS,X,
     1    CHOP,OMCHOP,IMCHOP,MRCHOP,
     1    SLICE,OMSLC,IMSLC,MRSLC
C
C	X-	INDICATES SPATIAL STEP
C	CHOP-	SPATIAL CHOP OF TUBULE
C       OMCHOP,IMCHOP,MRCHOP - REGIONAL CHOP FOR OM, IM AND MR
C       SLICE-  OM+IM+MR DISCRETIZATION OF GUESSES 
C               (REFINED TO OMCHOP+IMCHOP+MRCHOP BY LINEAR INTERPOLATION)
C               GAMMA VECTOR IS BASED ON SLICE
C
C GENERAL PARAMETERS
	DOUBLE PRECISION
     1   Z(15),PKC,PKF,PKN,PKP,KHY,KDHY,
     1   SCV, SCAMM, VMAT(20,10)
C
C       SCV-  scaling of volume flows to get muL/min
C       SCAMM-scaling of ammonia flows to get nmol/min
C       VMAT- contains entries for the transport tableau 
C
C SPECIFIED BOUNDARY DATA
C
        DOUBLE PRECISION
     1   CSMR(15,201,2),CSOM(15,101,2),CSIM(15,501,2),
     1   PSMR(201,2),PSOM(101,2),PSIM(501,2),
     1   CSGAM(15,91),PSGAM(91),KEPSI,FVCGAM(91),FVCMR(201,2),
     1   PS0(3),IMPM0(2),IMPS0(3),CM0(15,2),CS0(16,3), 
     1   FVC0(4),PC0(4),IMPC0(4),HCT0(4),CC0(16,4)
C
C       CSMR,CSOM,CSIM- CS CONCENTRATIONS AT GRID POINTS (FOR EXPORT TO NEPHRON AND VASC)
C       PSMR,PSOM,PSIM- PS VALUES AT GRID POINTS (FOR EXPORT TO NEPHRON AND VASC)
C       CSGAM-  GUESS CS CONCENTRATIONS AT SLICE BOUNDARIES
C       PSGAM-  GUESS PS VALUES AT SLICE BOUNDARIES
C       KEPSI-   ERROR TOLERANCE FOR THE KIDNEY ITERATIONS
C       FVCGAM- GUESS AT CAPILLARY VOUME UPTAKE AT SLICE BOUNDARIES
C       FVCMR-  FVC VALUES AT GRID POINTS WITHIN MR
C
C	FVMO(1) and FVM0(2)- SFPCT and JMPCT(2) flows for all SF and JM(2) nephrons
C	PSO- 	SFPCT, JMPCT, and DCT/CNT vascular pressures (uniform)
C	IMPM0- filtered impermeant osmolality
C	IMPS0- vascular impermeant osmolality for SFPCT, JMPCT, and DCT/CNT (mM)
C	CM0-	glomerular filtrate composition
C	CS0-	vascular plasma composition for SFPCT, JMPCT, and DCT/CNT
C	CSMR-	cortical composition within medullary ray
C
C	FVC0-	capillary plasma flow for individual OMDVR, OIDVR, and MRDVR
C	PC0-	capillary pressures
C	IMPC0- 	capillary protein concentration (gm/dl)
C	HCT0-	hematocrits
C	CC0-	capillary solute composition
C
C
        DOUBLE PRECISION
     1    OMDIST(501),IMDIST(501),MRDIST(501),
     1    OMJVMS(501),OMJKMS(16,501),
     1    IMJVMS(501),IMJKMS(16,501),
     1    MRJVMS(501),MRJKMS(16,501),
     1    MEDJVMS(91),MEDJKMS(16,91),
     1    SEGV(6,14),SEGK(6,14,16)
C
C VARIABLES SHARED WITH GEN
C       DIST-  MEDULLARY DEPTH
C       JVMS-  TOTAL VOLUME FLUX FROM TUBULES TO IS (FEVM + FIVM)
C       JKMS-  TOTAL SOLUTE FLUX FROM TUBULES TO IS (FEKM + FIKM)
C       MEDJMS-SUMMATION OF FLUXES FOR EACH MM SLICE OF MEDULLA OM->TIP
C       SEGV,SEGK-  SEGMENTAL FLUX SUMS; COMPONENTS OF JVMS AND JKMS:
C
        DOUBLE PRECISION
     1    OMJVCS(501),OMJKCS(16,501),
     1    IMJVCS(501),IMJKCS(16,501),
     1    MRJVCS(501),MRJKCS(16,501),
     1    MEDJVCS(91),MEDJKCS(16,91),
     1    VSEGV(9,4),VSEGK(9,4,16)
C
C VARIABLES SHARED WITH VGEN
C       JVCS-  TOTAL VOLUME FLUX FROM VR TO IS        
C       JKCS-  TOTAL SOLUTE FLUX FROM VR TO IS
C       MEDJCS-SUMMATION OF FLUXES FOR EACH MM SLICE OF MEDULLA OM->TIP
C       VSEGV,VSEGK-  SEGMENTAL FLUX SUMS; COMPONENTS OF JVCS AND JKCS:
C           OMJCS = SUM(SEG(I,1) + SEG(I,4)), I=1,7
C           IMJCS = SUM(SEG(I,2) + SEG(I,3)), I=3,7
C
C
C  Calculation plan: 
C  SFPCT -> SFPST -> SDHL -> AHLm -> AHLc -> DCT
C  JMPCT -> JMPST -> LDHLu -> LDHLl(2-6) -> tAHL(2-6) -> AHLm(2-6) -> AHLc(2-6) -> DCT(2-6)
C  Merged DCT -> CNT -> CCD -> OMCD -> IMCD
C 
C KEY TO INDICES:
C  6 nephrons: SF (INEPH = 1) plus 5 JM (INEPH = 2-6)
C    SFPCT and SFPST in series with SDHL
C    JMPCT and JMPST in series with LDHLu and LDHLl
C  LDHLu will be restricted to OM and LDHLl to IM
C
C Segment numbers (ISEG)
C      1- PCT
C      2- PST
C      3- sDHL, lDHLu
C      4- lDHLl
C      5- tAHL
C      6- AHLm
C      7- AHLc
C      8- DCT
C      9- CNT
C      10-CCD
C      11-OMCD
C      12-IMCD
C      13-PSTMR
C
C VASA RECTA INDEX (IVR)
C  SDVR -> SAVR (1,2)
C  LDVR(OM) -> LDVR(IM) -> LAVR(IM) -> LAVR(OM) (3,7)
C  MRDVR -> MRAVR (8)
C
C Segment numbers (ISEG)
C      1- OMDVR,OIDVR,MRDVR
C      2- IMDVR
C      3- IMAVR
C      4- OMAVR,OIAVR,MRAVR
C
	DOUBLE PRECISION PHI(1008),SRCV(91),SRCK(16,91)
C       SRC*-   INTERSTITIAL "SOURCE" OF VOLUME OR SOLUTE = EXPORT TO NEPHRON PLUS VESSELS
C
C ARCHIVED NEPHRON VARIABLES
C
	INTEGER 
     1   RX(6,14), RCHOP(6,14)
C
C GENERAL PARAMETERS
	DOUBLE PRECISION
     1   RDIST(6,14), REPSI(6,14), RL0(6,14),
     1   RL(6,14,501,2), RKHY(6,14,5), RKDHY(6,14,5), RBCO2(6,14,3)
C
C LUMINAL AND PERITUBULAR PARAMETERS
	DOUBLE PRECISION
     1   RVM(6,14,501,2), RPM(6,14,501,2), RCM(6,14,15,501,2),
     1   RIMPM(6,14,501,2), RLCHM(6,14,501), RXM(6,14,15,501),
     1   RVS(6,14,501,2), RPS(6,14,501,2), RCS(6,14,15,501,2),
     1   RIMPS(6,14,501,2), RLCHS(6,14,501), RXS(6,14,15,501),
     1   RTL(6,14), RDX(6,14), RRM0(6,14),
     1   RMUM(6,14), RETA(6,14), RSM(6,14,501,2),
     1   RAM(6,14,501,2), RFVM(6,14,501,2), RFKM(6,14,16,501,2)
C
C INTERSPACE PARAMETERS
	DOUBLE PRECISION
     1   RAME(6,14), RAE0(6,14), RAE(6,14,501,2),
     1   RMUA(6,14), RCHVL0(6,14), RCHVL(6,14,501,2),
     1   RMUV(6,14), RLPME(6,14), RLPES(6,14),
     1   RSME(6,14,15), RSES(6,14,15), RHME(6,14,15),
     1   RHES(6,14,15), RVE(6,14,501,2), RPE(6,14,501,2),
     1   RCE(6,14,15,501,2), RLCHE(6,14,501), RXE(6,14,15,501),
     1   RFEVM(6,14,501,2), RFEKM(6,14,15,501,2), RFEVS(6,14,501,2),
     1   RFEKS(6,14,15,501,2), RCURE(6,14,501)
C
C CELL PARAMETERS
	DOUBLE PRECISION
     1   RAIE(6,14,3), RAMI(6,14,3), RAIS(6,14,3),
     1   RAI0(6,14,3), RCLVL0(6,14,3), RIMP0(6,14,3),
     1   RCLVL(6,14,3,501,2), RZIMP(6,14,3), RTBUF(6,14,3),
     1   RPKB(6,14,3), RCBUF(6,14,3,501,2), RHCBUF(6,14,3,501,2),
     1   RLPMI(6,14,3), RLPIS(6,14,3), RSMI(6,14,3,15),
     1   RSIS(6,14,3,15), RHMI(6,14,3,15), RHIS(6,14,3,15),
     1   RLMI(6,14,3,15,15), RLIS(6,14,3,15,15), RATMI(6,14,3,15,501),
     1   RATIS(6,14,3,15,501), RATIE(6,14,3,15,501), RVI(6,14,3,501,2),
     1   RPI(6,14,3,501,2), RCI(6,14,3,15,501,2), RIMP(6,14,3,501),
     1   RLCHI(6,14,3,501), RXI(6,14,3,15,501), RFIVM(6,14,3,501,2),
     1   RFIKM(6,14,3,15,501,2), RFIVS(6,14,3,501,2), 
     1   RFIKS(6,14,3,15,501,2), RCURI(6,14,3,501), 
     1   RJV(6,14,3,501,2), RJK(6,14,3,15,501,2)
C
C SPECIAL TRANSPORTERS
	CHARACTER*1 RISOFM(6,14)
	DOUBLE PRECISION
     1   RNP(6,14,3), RKNPN(6,14,3), RKNPK(6,14,3),
     1   RKNH4(6,14,3), RNPHK(6,14,3), RLHP(6,14,3),
     1   RXIHP(6,14,3), RXHP(6,14,3), RNAE1(6,14,3),
     1   RNTSC(6,14,3), RNNHE3(6,14,3), RJNAK(6,14,3,3,501,2),
     1   RJHK(6,14,3,501,2), RJHP(6,14,3,501,2), RJAE1(6,14,3,501,2),
     1   RJTSC(6,14,3,501,2), RJNHE3(6,14,3,3,501,2), RQIAMM(6,14),
     1   RNNKCC(6,14,3), RNKCL(6,14,3), RJNKCC(6,14,3,4,501,2),
     1   RJKCC(6,14,3,3,501,2)
C
C TORQUE AND COMPLIANCE VARIABLES
	DOUBLE PRECISION
     1   RTQM(6,14,501,2), RRM(6,14,501,2), RMUR(6,14), RSCALMI(6,14),
     1   RSCALIS(6,14), RVM0(6,14), RAM0(6,14), RTQM0(6,14),
     1   RLHP0(6,14,3), RNP0(6,14,3), RNNHE30(6,14,3), RLPMI0(6,14,3),
     1   RLPIS0(6,14,3), RHMI0(6,14,3,15), RHIS0(6,14,3,15),
     1   RLMI0(6,14,3,15,15), RLIS0(6,14,3,15,15), RQIAMM0(6,14),
     1   RMVL(6,14), RMVD(6,14), RRMT0(6,14)
C
C TGF VARIABLES: STARTING WITH THE BASELINE SNGFR, 
C   IT IS ADJUSTED ACCORDING TO MACULA DENSA CELL [CL-] 
C INITIAL PT PRESSURE IS ADJUSTED ACCORDING TO A DISTAL NEPHRON RESISTANCE
C
	DOUBLE PRECISION 
     1   FVM0(2),AFVM(6),DFVM(6),AFVM0(2),DFVM0(2),MDCL(2),DMDCL(2),
     1   TGGAM(15),TGPHI(15),TGPPHI(15),TGEPSI,NDERIV(15,15),
     1   TGDGAM(15),TGDELG(15),MAXPHI,RPHI(15),DNR
C	
C	FVM0-	SNGFR READ FROM BOUND.DAT-INDEX FOR SF (1) OR JM (2)
C	AFVM-	FIXED COMPONENT OF FVM0
C	DFVM-	COMPONENT OF FVM0 THAT CAN BE MODULATED BY TGF
C	MDCL-	MACULA DENSA CL- REFERENCE CONCENTRATION
C	DMDCL-	MACULA DENSA CL- RANGE YIELDING DFVM
C	TGGAM-	TG FEEDBACK VARIABLE (CHANGE IN FV)
C               1-      SF FVM(1)/FVM0(1)
C               2-      SF PM(1)
C               2J-1-   JM FVM(1)/FVM0(2), J=2,6
C               2J-     JM PM(1)
C               13-     CNT PM(1)
C	TGPHI-	TG FEEDBACK RELATION
C               2J-1-   TGF RELATIONS, J=1,6
C         TGPHI(2J-1) = FVM(0) - AFVM - (DFVM / DMDCL) * [MDCL - CIAHL]
C               2J-     MATCHING PRESSURES AT CNT ENTRY 
C         TGPHI(2J) = PM-END-DCT = PM-CNT
C               13-   IMCD PM(L) - DNR
C  old    TGPHI(13) = CNT PM(1) - DNR*FVMCNT
C	TGEPSI-	TG FEEDBACK ERROR
C	NDERIV-	TG FEEDBACK JACOBIAN 
C	TGDGAM-	TG FEEDBACK VARIABLE INCREMENT
C	TGDELG-	TG FEEDBACK VARIABLE NEWTON CORRECTION
C
C VASC:
C
        DOUBLE PRECISION RADVR(9),RDNUM(9),RANUM(9)
C
	INTEGER 
     1   RVX(9,4), RVCHOP(9,4)
C PARAMETERS
	DOUBLE PRECISION
     1   RVEPSI(9,4),RVDIST(9,4),RVKHY(9,4),RVKDHY(9,4),
     1   RVDX(9,4),RVETA(9,4),RCL(9,4),RRC0(9,4),RMUC(9,4),
     1   RLPCS(9,4),RSCS(9,4,15),RLCS(9,4,15),RHCS(9,4,15),
     1   RLPCSE(9,4),RSCSE(9,4,15),RLCSE(9,4,15),RHCSE(9,4,15),
     1   RLPCSI(9,4),RSCSI(9,4,15),RLCSI(9,4,15),RHCSI(9,4,15)
C VARIABLES
	DOUBLE PRECISION
     1   RVVS(9,4,501,2),RVPS(9,4,501,2),RVCS(9,4,16,501,2),
     1   RVIMPS(9,4,501,2),RVLCHS(9,4,501),RVXS(9,4,15,501),
     1   RVC(9,4,501,2),RPC(9,4,501,2),RCC(9,4,31,501,2),
     1   RIMPC(9,4,501,2),RLCHC(9,4,501),RXC(9,4,15,501),
     1   RSAT(9,4,501,2),RCCN(9,4,501,2),
     1   RCCX(9,4,501,2),RCCY(9,4,501,2),RPOX(9,4,501,2),
     1   RSC(9,4,501,2),RAC(9,4,501,2),RFVC(9,4,501,2),
     1   RFKC(9,4,31,501,2),RFVCS(9,4,501,2),RFKCS(9,4,16,501,2),
     1   RFVCSE(9,4,501,2),RFKCSE(9,4,16,501,2),RFVCSI(9,4,501,2),
     1   RFKCSI(9,4,16,501,2),RHCTC(9,4,501,2),RFBC(9,4,501,2)
C
C	
C FOR THE BASELINE CONFIRGURATION:
C  SLICE DEMARCATIONS AT 0 - 7 MM FROM OM TO PAPILLA
C  THE INITIAL POINT AT 0 MM CORRESPONDS TO A SINGLE MR SLICE, 2MM IN THICKNESS
C Interstitial unknows are pressure and concentration at 2 points in OM, 5 points
C  in IM, and one point in MR.  The x=0 point in OM abuts PST; there is a second
c  x=0 point in OM that is identified with MR=2mm, and this abuts AHL and OMCD.
C The points MR(1) and OM(1) will be assigned cortical concentrations, so there
C  are a total of 8 sets of IS unknowns.
C
C                                       MR(1)
C
C                                       MR(2)
C                _____________________________________ (continuity MR->OM)
C                        OM(1)          MR(2)
C                             \        /
C                             OM(2)=MR(3)
C                             OM(3)=MR(4)
C                _____________________________________ (continuity OM->IM)
C                                OM(3)
C                                IM(1)
C                                 ...
C                                IM(5)
C
	NTUB=6
C
C  SOLUTE INDEX:
C	1-	NA+
C	2-	K+
C	3-	CL-
C	4-	HCO3-
C	5-	H2CO3
C	6-	CO2
C	7-	HPO4--
C	8-	H2PO4-
C	9-	UREA
C	10-	NH3
C	11-	NH4+
C	12-	H+
C	13-	HCO2-
C	14-	H2CO2
C	15-	GLUC
C
        SOLS=15
C SCV = 60 -> mL/min   SCAMM = 60,000 -> mumol/min
        SCV= 60.
        SCAMM= 6.D4

C Nephron and Vessel ammonia flow includes NH3 and NH4
C  Adding CO2 for comparison - 
C   include the two carbamino species within total CO2: (21)-ONHCO2- (22)-NHCO2-
C
C Cortex - Cap
        VMAT(1,1) = SCV*RFVC(9,1,1,1)
        VMAT(1,2) = SCV*VSEGV(9,1)
        VMAT(1,3) = SCV*RFVC(9,1,2,1)
C
        VMAT(1,4) = SCAMM*(RFKC(9,1,10,1,1)+RFKC(9,1,11,1,1))
        VMAT(1,5) = SCAMM*(VSEGK(9,1,10)+VSEGK(9,1,11))
        VMAT(1,6) = SCAMM*(RFKC(9,1,10,2,1)+RFKC(9,1,11,2,1))
C
        VMAT(1,7) = SCAMM*(RFKC(9,1,4,1,1)+RFKC(9,1,5,1,1)+
     1   RFKC(9,1,6,1,1)+RFKC(9,1,21,1,1)+RFKC(9,1,22,1,1))
        VMAT(1,8) = SCAMM*(VSEGK(9,1,4)+VSEGK(9,1,5)+VSEGK(9,1,6))
        VMAT(1,9) = SCAMM*(RFKC(9,1,4,2,1)+RFKC(9,1,5,2,1)+
     1   RFKC(9,1,6,2,1)+RFKC(9,1,21,2,1)+RFKC(9,1,22,2,1))
C Cortex - PCT
        VMAT(2,1) = SCV*(RFVM(1,1,1,1)+RFVM(2,1,1,1)+RFVM(3,1,1,1)+
     1   RFVM(4,1,1,1)+RFVM(5,1,1,1)+RFVM(6,1,1,1))
        VMAT(2,2) = SCV*(SEGV(1,1)+SEGV(2,1)+SEGV(3,1)+
     1   SEGV(4,1)+SEGV(5,1)+SEGV(6,1))
        VMAT(2,3) = SCV*(
     1    RFVM(1,1,1+RCHOP(1,1),1)+RFVM(2,1,1+RCHOP(2,1),1)+
     1    RFVM(3,1,1+RCHOP(3,1),1)+RFVM(4,1,1+RCHOP(4,1),1)+
     1    RFVM(5,1,1+RCHOP(5,1),1)+RFVM(6,1,1+RCHOP(6,1),1))
C
        VMAT(2,4) = SCAMM*(RFKM(1,1,10,1,1)+RFKM(1,1,11,1,1)+
     1    RFKM(2,1,10,1,1)+RFKM(2,1,11,1,1)+
     1    RFKM(3,1,10,1,1)+RFKM(3,1,11,1,1)+
     1    RFKM(4,1,10,1,1)+RFKM(4,1,11,1,1)+
     1    RFKM(5,1,10,1,1)+RFKM(5,1,11,1,1)+
     1    RFKM(6,1,10,1,1)+RFKM(6,1,11,1,1))
        VMAT(2,5) = SCAMM*(SEGK(1,1,10)+SEGK(1,1,11)+
     1    SEGK(2,1,10)+SEGK(2,1,11)+
     1    SEGK(3,1,10)+SEGK(3,1,11)+
     1    SEGK(4,1,10)+SEGK(4,1,11)+
     1    SEGK(5,1,10)+SEGK(5,1,11)+
     1    SEGK(6,1,10)+SEGK(6,1,11))
        VMAT(2,6) = SCAMM*(
     1    RFKM(1,1,10,1+RCHOP(1,1),1)+RFKM(1,1,11,1+RCHOP(1,1),1)+
     1    RFKM(2,1,10,1+RCHOP(2,1),1)+RFKM(2,1,11,1+RCHOP(2,1),1)+
     1    RFKM(3,1,10,1+RCHOP(3,1),1)+RFKM(3,1,11,1+RCHOP(3,1),1)+
     1    RFKM(4,1,10,1+RCHOP(4,1),1)+RFKM(4,1,11,1+RCHOP(4,1),1)+
     1    RFKM(5,1,10,1+RCHOP(5,1),1)+RFKM(5,1,11,1+RCHOP(5,1),1)+
     1    RFKM(6,1,10,1+RCHOP(6,1),1)+RFKM(6,1,11,1+RCHOP(6,1),1))
C
        VMAT(2,7) = SCAMM*(
     1    RFKM(1,1,4,1,1)+RFKM(1,1,5,1,1)+RFKM(1,1,6,1,1)+
     1    RFKM(2,1,4,1,1)+RFKM(2,1,5,1,1)+RFKM(2,1,6,1,1)+
     1    RFKM(3,1,4,1,1)+RFKM(3,1,5,1,1)+RFKM(3,1,6,1,1)+
     1    RFKM(4,1,4,1,1)+RFKM(4,1,5,1,1)+RFKM(4,1,6,1,1)+
     1    RFKM(5,1,4,1,1)+RFKM(5,1,5,1,1)+RFKM(5,1,6,1,1)+
     1    RFKM(6,1,4,1,1)+RFKM(6,1,5,1,1)+RFKM(6,1,6,1,1))
        VMAT(2,8) = SCAMM*(
     1    SEGK(1,1,4)+SEGK(1,1,5)+SEGK(1,1,6)+
     1    SEGK(2,1,4)+SEGK(2,1,5)+SEGK(2,1,6)+
     1    SEGK(3,1,4)+SEGK(3,1,5)+SEGK(3,1,6)+
     1    SEGK(4,1,4)+SEGK(4,1,5)+SEGK(4,1,6)+
     1    SEGK(5,1,4)+SEGK(5,1,5)+SEGK(5,1,6)+
     1    SEGK(6,1,4)+SEGK(6,1,5)+SEGK(6,1,6))
        VMAT(2,9) = SCAMM*(
     1    RFKM(1,1,4,1+RCHOP(1,1),1)+RFKM(1,1,5,1+RCHOP(1,1),1)+
     1     RFKM(1,1,6,1+RCHOP(1,1),1)+
     1    RFKM(2,1,4,1+RCHOP(2,1),1)+RFKM(2,1,5,1+RCHOP(2,1),1)+
     1     RFKM(2,1,6,1+RCHOP(2,1),1)+
     1    RFKM(3,1,4,1+RCHOP(3,1),1)+RFKM(3,1,5,1+RCHOP(3,1),1)+
     1     RFKM(3,1,6,1+RCHOP(3,1),1)+
     1    RFKM(4,1,4,1+RCHOP(4,1),1)+RFKM(4,1,5,1+RCHOP(4,1),1)+
     1     RFKM(4,1,6,1+RCHOP(4,1),1)+
     1    RFKM(5,1,4,1+RCHOP(5,1),1)+RFKM(5,1,5,1+RCHOP(5,1),1)+
     1     RFKM(5,1,6,1+RCHOP(5,1),1)+
     1    RFKM(6,1,4,1+RCHOP(6,1),1)+RFKM(6,1,5,1+RCHOP(6,1),1)+
     1     RFKM(6,1,6,1+RCHOP(6,1),1))
C Cortex - DCT
        VMAT(3,1) = SCV*(RFVM(1,8,1,1)+RFVM(2,8,1,1)+RFVM(3,8,1,1)+
     1   RFVM(4,8,1,1)+RFVM(5,8,1,1)+RFVM(6,8,1,1))
        VMAT(3,2) = SCV*(SEGV(1,8)+SEGV(2,8)+SEGV(3,8)+
     1   SEGV(4,8)+SEGV(5,8)+SEGV(6,8))
        VMAT(3,3) = SCV*(
     1   RFVM(1,8,1+RCHOP(1,8),1)+RFVM(2,8,1+RCHOP(2,8),1)+
     1   RFVM(3,8,1+RCHOP(3,8),1)+RFVM(4,8,1+RCHOP(4,8),1)+
     1   RFVM(5,8,1+RCHOP(5,8),1)+RFVM(6,8,1+RCHOP(6,8),1))
C
        VMAT(3,4) = SCAMM*(RFKM(1,8,10,1,1)+RFKM(1,8,11,1,1)+
     1    RFKM(2,8,10,1,1)+RFKM(2,8,11,1,1)+
     1    RFKM(3,8,10,1,1)+RFKM(3,8,11,1,1)+
     1    RFKM(4,8,10,1,1)+RFKM(4,8,11,1,1)+
     1    RFKM(5,8,10,1,1)+RFKM(5,8,11,1,1)+
     1    RFKM(6,8,10,1,1)+RFKM(6,8,11,1,1))
        VMAT(3,5) = SCAMM*(SEGK(1,8,10)+SEGK(1,8,11)+
     1    SEGK(2,8,10)+SEGK(2,8,11)+
     1    SEGK(3,8,10)+SEGK(3,8,11)+
     1    SEGK(4,8,10)+SEGK(4,8,11)+
     1    SEGK(5,8,10)+SEGK(5,8,11)+
     1    SEGK(6,8,10)+SEGK(6,8,11))
        VMAT(3,6) = SCAMM*(
     1    RFKM(1,8,10,1+RCHOP(1,8),1)+RFKM(1,8,11,1+RCHOP(1,8),1)+
     1    RFKM(2,8,10,1+RCHOP(2,8),1)+RFKM(2,8,11,1+RCHOP(2,8),1)+
     1    RFKM(3,8,10,1+RCHOP(3,8),1)+RFKM(3,8,11,1+RCHOP(3,8),1)+
     1    RFKM(4,8,10,1+RCHOP(4,8),1)+RFKM(4,8,11,1+RCHOP(4,8),1)+
     1    RFKM(5,8,10,1+RCHOP(5,8),1)+RFKM(5,8,11,1+RCHOP(5,8),1)+
     1    RFKM(6,8,10,1+RCHOP(6,8),1)+RFKM(6,8,11,1+RCHOP(6,8),1))
C
        VMAT(3,7) = SCAMM*(
     1    RFKM(1,8,4,1,1)+RFKM(1,8,5,1,1)+RFKM(1,8,6,1,1)+
     1    RFKM(2,8,4,1,1)+RFKM(2,8,5,1,1)+RFKM(2,8,6,1,1)+
     1    RFKM(3,8,4,1,1)+RFKM(3,8,5,1,1)+RFKM(3,8,6,1,1)+
     1    RFKM(4,8,4,1,1)+RFKM(4,8,5,1,1)+RFKM(4,8,6,1,1)+
     1    RFKM(5,8,4,1,1)+RFKM(5,8,5,1,1)+RFKM(5,8,6,1,1)+
     1    RFKM(6,8,4,1,1)+RFKM(6,8,5,1,1)+RFKM(6,8,6,1,1))
        VMAT(3,8) = SCAMM*(
     1    SEGK(1,8,4)+SEGK(1,8,5)+SEGK(1,8,6)+
     1    SEGK(2,8,4)+SEGK(2,8,5)+SEGK(2,8,6)+
     1    SEGK(3,8,4)+SEGK(3,8,5)+SEGK(3,8,6)+
     1    SEGK(4,8,4)+SEGK(4,8,5)+SEGK(4,8,6)+
     1    SEGK(5,8,4)+SEGK(5,8,5)+SEGK(5,8,6)+
     1    SEGK(6,8,4)+SEGK(6,8,5)+SEGK(6,8,6))
        VMAT(3,9) = SCAMM*(
     1    RFKM(1,8,4,1+RCHOP(1,8),1)+RFKM(1,8,5,1+RCHOP(1,8),1)+
     1     RFKM(1,8,6,1+RCHOP(1,8),1)+
     1    RFKM(2,8,4,1+RCHOP(2,8),1)+RFKM(2,8,5,1+RCHOP(2,8),1)+
     1     RFKM(2,8,6,1+RCHOP(2,8),1)+
     1    RFKM(3,8,4,1+RCHOP(3,8),1)+RFKM(3,8,5,1+RCHOP(3,8),1)+
     1     RFKM(3,8,6,1+RCHOP(3,8),1)+
     1    RFKM(4,8,4,1+RCHOP(4,8),1)+RFKM(4,8,5,1+RCHOP(4,8),1)+
     1     RFKM(4,8,6,1+RCHOP(4,8),1)+
     1    RFKM(5,8,4,1+RCHOP(5,8),1)+RFKM(5,8,5,1+RCHOP(5,8),1)+
     1     RFKM(5,8,6,1+RCHOP(5,8),1)+
     1    RFKM(6,8,4,1+RCHOP(6,8),1)+RFKM(6,8,5,1+RCHOP(6,8),1)+
     1     RFKM(6,8,6,1+RCHOP(6,8),1))
C Cortex - CNT
        VMAT(4,1) = SCV*RFVM(1,9,1,1)
        VMAT(4,2) = SCV*SEGV(1,9)
        VMAT(4,3) = VMAT(4,1) - VMAT(4,2)
C
        VMAT(4,4) = SCAMM*(RFKM(1,9,10,1,1)+RFKM(1,9,11,1,1))
        VMAT(4,5) = SCAMM*(SEGK(1,9,10)+SEGK(1,9,11))
C        VMAT(4,6) = VMAT(4,4) - VMAT(4,5)
        VMAT(4,6) = SCAMM*(
     1   RFKM(1,9,10,1+RCHOP(1,9),1)+RFKM(1,9,11,1+RCHOP(1,9),1))
C
        VMAT(4,7) = SCAMM*(RFKM(1,9,4,1,1)+RFKM(1,9,5,1,1)+
     1   RFKM(1,9,6,1,1))
        VMAT(4,8) = SCAMM*(SEGK(1,9,4)+SEGK(1,9,5)+SEGK(1,9,6))
        VMAT(4,9) = SCAMM*(
     1    RFKM(1,9,4,1+RCHOP(1,9),1)+RFKM(1,9,5,1+RCHOP(1,9),1)+
     1    RFKM(1,9,6,1+RCHOP(1,9),1))
C Cortex - Nephrons
        VMAT(5,1) = VMAT(2,1) + VMAT(3,1)
        VMAT(5,2) = VMAT(2,2) + VMAT(3,2) + VMAT(4,2)
        VMAT(5,3) = VMAT(2,3) + VMAT(4,3)
C
        VMAT(5,4) = VMAT(2,4) + VMAT(3,4)
        VMAT(5,5) = VMAT(2,5) + VMAT(3,5) + VMAT(4,5)
        VMAT(5,6) = VMAT(2,6) + VMAT(4,6)
C
        VMAT(5,7) = VMAT(2,7) + VMAT(3,7)
        VMAT(5,8) = VMAT(2,8) + VMAT(3,8) + VMAT(4,8)
        VMAT(5,9) = VMAT(2,9) + VMAT(4,9)
C
C MR - Cap
        VMAT(6,1) = SCV*RVCHOP(8,1)*RDNUM(8)*RFVC(8,1,1,1)
        VMAT(6,2) = SCV*VSEGV(8,4)
        VMAT(6,3) = VMAT(6,1) - VMAT(6,2)
C
        VMAT(6,4) = SCAMM*RVCHOP(8,1)*RDNUM(8)*
     1    (RFKC(8,1,10,1,1)+RFKC(8,1,11,1,1))
        VMAT(6,5) = SCAMM*(VSEGK(8,4,10)+VSEGK(8,4,11))
        VMAT(6,6) = VMAT(6,4) - VMAT(6,5)
C
        VMAT(6,7) = SCAMM*RVCHOP(8,1)*RDNUM(8)*
     1    (RFKC(8,1,4,1,1)+RFKC(8,1,5,1,1)+RFKC(8,1,6,1,1)+
     1      RFKC(8,1,21,1,1)+RFKC(8,1,22,1,1))
        VMAT(6,8) = SCAMM*(VSEGK(8,4,4)+VSEGK(8,4,5)+VSEGK(8,4,6))
        VMAT(6,9) = VMAT(6,7) - VMAT(6,8)
C MR - MRPST
        VMAT(7,1) = SCV*RFVM(1,13,1,1)
        VMAT(7,2) = SCV*SEGV(1,13)
C        VMAT(7,3) = VMAT(7,1) - VMAT(7,2)
        VMAT(7,3) = SCV*RFVM(1,13,1+RCHOP(1,13),1)
C
        VMAT(7,4) = SCAMM*(RFKM(1,13,10,1,1)+RFKM(1,13,11,1,1))
        VMAT(7,5) = SCAMM*(SEGK(1,13,10)+SEGK(1,13,11))
        VMAT(7,6) = SCAMM*(
     1   RFKM(1,13,10,1+RCHOP(1,13),1)+RFKM(1,13,11,1+RCHOP(1,13),1))
C
        VMAT(7,7) = SCAMM*(RFKM(1,13,4,1,1)+RFKM(1,13,5,1,1)+
     1    RFKM(1,13,6,1,1))
        VMAT(7,8) = SCAMM*(SEGK(1,13,4)+SEGK(1,13,5)+SEGK(1,13,6))
        VMAT(7,9) = SCAMM*(
     1   RFKM(1,13,4,1+RCHOP(1,13),1)+RFKM(1,13,5,1+RCHOP(1,13),1)+
     1    RFKM(1,13,6,1+RCHOP(1,13),1))
C MR - AHLc
        VMAT(8,1) = SCV*(RFVM(1,7,1,1)+RFVM(2,7,1,1)+RFVM(3,7,1,1)+
     1   RFVM(4,7,1,1)+RFVM(5,7,1,1)+RFVM(6,7,1,1))
        VMAT(8,2) = SCV*(SEGV(1,7)+SEGV(2,7)+SEGV(3,7)+
     1   SEGV(4,7)+SEGV(5,7)+SEGV(6,7))
        VMAT(8,3) = SCV*(
     1   RFVM(1,7,1+RCHOP(1,7),1)+RFVM(2,7,1+RCHOP(2,7),1)+
     1   RFVM(3,7,1+RCHOP(3,7),1)+RFVM(4,7,1+RCHOP(4,7),1)+
     1   RFVM(5,7,1+RCHOP(5,7),1)+RFVM(6,7,1+RCHOP(6,7),1))
C
        VMAT(8,4) = SCAMM*(RFKM(1,7,10,1,1)+RFKM(1,7,11,1,1)+
     1    RFKM(2,7,10,1,1)+RFKM(2,7,11,1,1)+
     1    RFKM(3,7,10,1,1)+RFKM(3,7,11,1,1)+
     1    RFKM(4,7,10,1,1)+RFKM(4,7,11,1,1)+
     1    RFKM(5,7,10,1,1)+RFKM(5,7,11,1,1)+
     1    RFKM(6,7,10,1,1)+RFKM(6,7,11,1,1))
        VMAT(8,5) = SCAMM*(SEGK(1,7,10)+SEGK(1,7,11)+
     1    SEGK(2,7,10)+SEGK(2,7,11)+
     1    SEGK(3,7,10)+SEGK(3,7,11)+
     1    SEGK(4,7,10)+SEGK(4,7,11)+
     1    SEGK(5,7,10)+SEGK(5,7,11)+
     1    SEGK(6,7,10)+SEGK(6,7,11))
        VMAT(8,6) = SCAMM*(
     1    RFKM(1,7,10,1+RCHOP(1,7),1)+RFKM(1,7,11,1+RCHOP(1,7),1)+
     1    RFKM(2,7,10,1+RCHOP(2,7),1)+RFKM(2,7,11,1+RCHOP(2,7),1)+
     1    RFKM(3,7,10,1+RCHOP(3,7),1)+RFKM(3,7,11,1+RCHOP(3,7),1)+
     1    RFKM(4,7,10,1+RCHOP(4,7),1)+RFKM(4,7,11,1+RCHOP(4,7),1)+
     1    RFKM(5,7,10,1+RCHOP(5,7),1)+RFKM(5,7,11,1+RCHOP(5,7),1)+
     1    RFKM(6,7,10,1+RCHOP(6,7),1)+RFKM(6,7,11,1+RCHOP(6,7),1))
C
        VMAT(8,7) = SCAMM*(
     1    RFKM(1,7,4,1,1)+RFKM(1,7,5,1,1)+RFKM(1,7,6,1,1)+
     1    RFKM(2,7,4,1,1)+RFKM(2,7,5,1,1)+RFKM(2,7,6,1,1)+
     1    RFKM(3,7,4,1,1)+RFKM(3,7,5,1,1)+RFKM(3,7,6,1,1)+
     1    RFKM(4,7,4,1,1)+RFKM(4,7,5,1,1)+RFKM(4,7,6,1,1)+
     1    RFKM(5,7,4,1,1)+RFKM(5,7,5,1,1)+RFKM(5,7,6,1,1)+
     1    RFKM(6,7,4,1,1)+RFKM(6,7,5,1,1)+RFKM(6,7,6,1,1))
        VMAT(8,8) = SCAMM*(
     1    SEGK(1,7,4)+SEGK(1,7,5)+SEGK(1,7,6)+
     1    SEGK(2,7,4)+SEGK(2,7,5)+SEGK(2,7,6)+
     1    SEGK(3,7,4)+SEGK(3,7,5)+SEGK(3,7,6)+
     1    SEGK(4,7,4)+SEGK(4,7,5)+SEGK(4,7,6)+
     1    SEGK(5,7,4)+SEGK(5,7,5)+SEGK(5,7,6)+
     1    SEGK(6,7,4)+SEGK(6,7,5)+SEGK(6,7,6))
        VMAT(8,9) = SCAMM*(
     1    RFKM(1,7,4,1+RCHOP(1,7),1)+RFKM(1,7,5,1+RCHOP(1,7),1)+
     1     RFKM(1,7,6,1+RCHOP(1,7),1)+
     1    RFKM(2,7,4,1+RCHOP(2,7),1)+RFKM(2,7,5,1+RCHOP(2,7),1)+
     1     RFKM(2,7,6,1+RCHOP(2,7),1)+
     1    RFKM(3,7,4,1+RCHOP(3,7),1)+RFKM(3,7,5,1+RCHOP(3,7),1)+
     1     RFKM(3,7,6,1+RCHOP(3,7),1)+
     1    RFKM(4,7,4,1+RCHOP(4,7),1)+RFKM(4,7,5,1+RCHOP(4,7),1)+
     1     RFKM(4,7,6,1+RCHOP(4,7),1)+
     1    RFKM(5,7,4,1+RCHOP(5,7),1)+RFKM(5,7,5,1+RCHOP(5,7),1)+
     1     RFKM(5,7,6,1+RCHOP(5,7),1)+
     1    RFKM(6,7,4,1+RCHOP(6,7),1)+RFKM(6,7,5,1+RCHOP(6,7),1)+
     1     RFKM(6,7,6,1+RCHOP(6,7),1))
C MR - CCD
        VMAT(9,1) = SCV*RFVM(1,10,1,1)
        VMAT(9,2) = SCV*SEGV(1,10)
        VMAT(9,3) = SCV*RFVM(1,10,1+RCHOP(1,10),1)
C
        VMAT(9,4) = SCAMM*(RFKM(1,10,10,1,1)+RFKM(1,10,11,1,1))
        VMAT(9,5) = SCAMM*(SEGK(1,10,10)+SEGK(1,10,11))
        VMAT(9,6) = SCAMM*(
     1   RFKM(1,10,10,1+RCHOP(1,10),1)+RFKM(1,10,11,1+RCHOP(1,10),1))
C
        VMAT(9,7) = SCAMM*(RFKM(1,10,4,1,1)+RFKM(1,10,5,1,1)+
     1   RFKM(1,10,6,1,1))
        VMAT(9,8) = SCAMM*(SEGK(1,10,4)+SEGK(1,10,5)+SEGK(1,10,6))
        VMAT(9,9) = SCAMM*(
     1   RFKM(1,10,4,1+RCHOP(1,10),1)+RFKM(1,10,5,1+RCHOP(1,10),1)+
     1   RFKM(1,10,6,1+RCHOP(1,10),1))
C MR - Nephrons
        VMAT(10,1) = VMAT(7,1) + VMAT(8,1) + VMAT(9,1)
        VMAT(10,2) = VMAT(7,2) + VMAT(8,2) + VMAT(9,2)
        VMAT(10,3) = VMAT(7,3) + VMAT(8,3) + VMAT(9,3)
C
        VMAT(10,4) = VMAT(7,4) + VMAT(8,4) + VMAT(9,4)
        VMAT(10,5) = VMAT(7,5) + VMAT(8,5) + VMAT(9,5)
        VMAT(10,6) = VMAT(7,6) + VMAT(8,6) + VMAT(9,6)
C
        VMAT(10,7) = VMAT(7,7) + VMAT(8,7) + VMAT(9,7)
        VMAT(10,8) = VMAT(7,8) + VMAT(8,8) + VMAT(9,8)
        VMAT(10,9) = VMAT(7,9) + VMAT(8,9) + VMAT(9,9)
C
C Medulla - VR
        VMAT(11,1) = SCV*(
     1   RDNUM(1)*RFVC(1,1,1,1)+RDNUM(2)*RFVC(2,1,1,1)+
     1   RDNUM(3)*RFVC(3,1,1,1)+RDNUM(4)*RFVC(4,1,1,1)+
     1   RDNUM(5)*RFVC(5,1,1,1)+RDNUM(6)*RFVC(6,1,1,1)+
     1   RDNUM(7)*RFVC(7,1,1,1))
        VMAT(11,2) = SCV*(
     1    VSEGV(1,1)+VSEGV(2,1)+VSEGV(3,1)+VSEGV(4,1)+
     1     VSEGV(5,1)+VSEGV(6,1)+VSEGV(7,1)+
     1    VSEGV(3,2)+VSEGV(4,2)+VSEGV(5,2)+VSEGV(6,2)+VSEGV(7,2)+
     1    VSEGV(3,3)+VSEGV(4,3)+VSEGV(5,3)+VSEGV(6,3)+VSEGV(7,3)+
     1    VSEGV(1,4)+VSEGV(2,4)+VSEGV(3,4)+VSEGV(4,4)+
     1     VSEGV(5,4)+VSEGV(6,4)+VSEGV(7,4))
        VMAT(11,3) = VMAT(11,1) - VMAT(11,2)
C
        VMAT(11,4) = SCAMM*(
     1   RDNUM(1)*RFKC(1,1,10,1,1)+RDNUM(2)*RFKC(2,1,10,1,1)+
     1   RDNUM(3)*RFKC(3,1,10,1,1)+RDNUM(4)*RFKC(4,1,10,1,1)+
     1   RDNUM(5)*RFKC(5,1,10,1,1)+RDNUM(6)*RFKC(6,1,10,1,1)+
     1   RDNUM(7)*RFKC(7,1,10,1,1)+
     1   RDNUM(1)*RFKC(1,1,11,1,1)+RDNUM(2)*RFKC(2,1,11,1,1)+
     1   RDNUM(3)*RFKC(3,1,11,1,1)+RDNUM(4)*RFKC(4,1,11,1,1)+
     1   RDNUM(5)*RFKC(5,1,11,1,1)+RDNUM(6)*RFKC(6,1,11,1,1)+
     1   RDNUM(7)*RFKC(7,1,11,1,1))
        VMAT(11,5) = SCAMM*(
     1    VSEGK(1,1,10)+VSEGK(2,1,10)+VSEGK(3,1,10)+VSEGK(4,1,10)+
     1     VSEGK(5,1,10)+VSEGK(6,1,10)+VSEGK(7,1,10)+
     1    VSEGK(3,2,10)+VSEGK(4,2,10)+VSEGK(5,2,10)+
     1     VSEGK(6,2,10)+VSEGK(7,2,10)+
     1    VSEGK(3,3,10)+VSEGK(4,3,10)+VSEGK(5,3,10)+
     1     VSEGK(6,3,10)+VSEGK(7,3,10)+
     1    VSEGK(1,4,10)+VSEGK(2,4,10)+VSEGK(3,4,10)+VSEGK(4,4,10)+
     1     VSEGK(5,4,10)+VSEGK(6,4,10)+VSEGK(7,4,10)+
     1    VSEGK(1,1,11)+VSEGK(2,1,11)+VSEGK(3,1,11)+VSEGK(4,1,11)+
     1     VSEGK(5,1,11)+VSEGK(6,1,11)+VSEGK(7,1,11)+
     1    VSEGK(3,2,11)+VSEGK(4,2,11)+VSEGK(5,2,11)+
     1     VSEGK(6,2,11)+VSEGK(7,2,11)+
     1    VSEGK(3,3,11)+VSEGK(4,3,11)+VSEGK(5,3,11)+
     1     VSEGK(6,3,11)+VSEGK(7,3,11)+
     1    VSEGK(1,4,11)+VSEGK(2,4,11)+VSEGK(3,4,11)+VSEGK(4,4,11)+
     1     VSEGK(5,4,11)+VSEGK(6,4,11)+VSEGK(7,4,11))
        VMAT(11,6) = VMAT(11,4) - VMAT(11,5)
C
        VMAT(11,7) = SCAMM*(
     1   RDNUM(1)*RFKC(1,1,4,1,1)+RDNUM(2)*RFKC(2,1,4,1,1)+
     1   RDNUM(3)*RFKC(3,1,4,1,1)+RDNUM(4)*RFKC(4,1,4,1,1)+
     1   RDNUM(5)*RFKC(5,1,4,1,1)+RDNUM(6)*RFKC(6,1,4,1,1)+
     1   RDNUM(7)*RFKC(7,1,4,1,1)+
     1   RDNUM(1)*RFKC(1,1,5,1,1)+RDNUM(2)*RFKC(2,1,5,1,1)+
     1   RDNUM(3)*RFKC(3,1,5,1,1)+RDNUM(4)*RFKC(4,1,5,1,1)+
     1   RDNUM(5)*RFKC(5,1,5,1,1)+RDNUM(6)*RFKC(6,1,5,1,1)+
     1   RDNUM(7)*RFKC(7,1,5,1,1)+
     1   RDNUM(1)*RFKC(1,1,6,1,1)+RDNUM(2)*RFKC(2,1,6,1,1)+
     1   RDNUM(3)*RFKC(3,1,6,1,1)+RDNUM(4)*RFKC(4,1,6,1,1)+
     1   RDNUM(5)*RFKC(5,1,6,1,1)+RDNUM(6)*RFKC(6,1,6,1,1)+
     1   RDNUM(7)*RFKC(7,1,6,1,1)+
     1   RDNUM(1)*RFKC(1,1,21,1,1)+RDNUM(2)*RFKC(2,1,21,1,1)+
     1   RDNUM(3)*RFKC(3,1,21,1,1)+RDNUM(4)*RFKC(4,1,21,1,1)+
     1   RDNUM(5)*RFKC(5,1,21,1,1)+RDNUM(6)*RFKC(6,1,21,1,1)+
     1   RDNUM(7)*RFKC(7,1,21,1,1)+
     1   RDNUM(1)*RFKC(1,1,22,1,1)+RDNUM(2)*RFKC(2,1,22,1,1)+
     1   RDNUM(3)*RFKC(3,1,22,1,1)+RDNUM(4)*RFKC(4,1,22,1,1)+
     1   RDNUM(5)*RFKC(5,1,22,1,1)+RDNUM(6)*RFKC(6,1,22,1,1)+
     1   RDNUM(7)*RFKC(7,1,22,1,1))
        VMAT(11,8) = SCAMM*(
     1    VSEGK(1,1,4)+VSEGK(2,1,4)+VSEGK(3,1,4)+VSEGK(4,1,4)+
     1     VSEGK(5,1,4)+VSEGK(6,1,4)+VSEGK(7,1,4)+
     1    VSEGK(3,2,4)+VSEGK(4,2,4)+VSEGK(5,2,4)+
     1     VSEGK(6,2,4)+VSEGK(7,2,4)+
     1    VSEGK(3,3,4)+VSEGK(4,3,4)+VSEGK(5,3,4)+
     1     VSEGK(6,3,4)+VSEGK(7,3,4)+
     1    VSEGK(1,4,4)+VSEGK(2,4,4)+VSEGK(3,4,4)+VSEGK(4,4,4)+
     1     VSEGK(5,4,4)+VSEGK(6,4,4)+VSEGK(7,4,4)+
     1    VSEGK(1,1,5)+VSEGK(2,1,5)+VSEGK(3,1,5)+VSEGK(4,1,5)+
     1     VSEGK(5,1,5)+VSEGK(6,1,5)+VSEGK(7,1,5)+
     1    VSEGK(3,2,5)+VSEGK(4,2,5)+VSEGK(5,2,5)+
     1     VSEGK(6,2,5)+VSEGK(7,2,5)+
     1    VSEGK(3,3,5)+VSEGK(4,3,5)+VSEGK(5,3,5)+
     1     VSEGK(6,3,5)+VSEGK(7,3,5)+
     1    VSEGK(1,4,5)+VSEGK(2,4,5)+VSEGK(3,4,5)+VSEGK(4,4,5)+
     1     VSEGK(5,4,5)+VSEGK(6,4,5)+VSEGK(7,4,5)+
     1    VSEGK(1,1,6)+VSEGK(2,1,6)+VSEGK(3,1,6)+VSEGK(4,1,6)+
     1     VSEGK(5,1,6)+VSEGK(6,1,6)+VSEGK(7,1,6)+
     1    VSEGK(3,2,6)+VSEGK(4,2,6)+VSEGK(5,2,6)+
     1     VSEGK(6,2,6)+VSEGK(7,2,6)+
     1    VSEGK(3,3,6)+VSEGK(4,3,6)+VSEGK(5,3,6)+
     1     VSEGK(6,3,6)+VSEGK(7,3,6)+
     1    VSEGK(1,4,6)+VSEGK(2,4,6)+VSEGK(3,4,6)+VSEGK(4,4,6)+
     1     VSEGK(5,4,6)+VSEGK(6,4,6)+VSEGK(7,4,6))
        VMAT(11,9) = VMAT(11,7) - VMAT(11,8)
C Medulla - LOH
        VMAT(12,1) = SCV*(RFVM(1,2,1,1)+RFVM(2,2,1,1)+RFVM(3,2,1,1)+
     1   RFVM(4,2,1,1)+RFVM(5,2,1,1)+RFVM(6,2,1,1))
        VMAT(12,2) = SCV*(
     1   SEGV(1,2)+SEGV(2,2)+SEGV(3,2)+
     1   SEGV(4,2)+SEGV(5,2)+SEGV(6,2)+
     1   SEGV(1,3)+SEGV(2,3)+SEGV(3,3)+
     1   SEGV(4,3)+SEGV(5,3)+SEGV(6,3)+
     1   SEGV(2,4)+SEGV(3,4)+SEGV(4,4)+SEGV(5,4)+SEGV(6,4)+
     1   SEGV(2,5)+SEGV(3,5)+SEGV(4,5)+SEGV(5,5)+SEGV(6,5)+
     1   SEGV(1,6)+SEGV(2,6)+SEGV(3,6)+
     1   SEGV(4,6)+SEGV(5,6)+SEGV(6,6))
        VMAT(12,3) = VMAT(12,1) - VMAT(12,2)
C
        VMAT(12,4) = SCAMM*(RFKM(1,2,10,1,1)+RFKM(1,2,11,1,1)+
     1    RFKM(2,2,10,1,1)+RFKM(2,2,11,1,1)+
     1    RFKM(3,2,10,1,1)+RFKM(3,2,11,1,1)+
     1    RFKM(4,2,10,1,1)+RFKM(4,2,11,1,1)+
     1    RFKM(5,2,10,1,1)+RFKM(5,2,11,1,1)+
     1    RFKM(6,2,10,1,1)+RFKM(6,2,11,1,1))
        VMAT(12,5) = SCAMM*(SEGK(1,2,10)+SEGK(1,2,11)+
     1    SEGK(2,2,10)+SEGK(2,2,11)+
     1    SEGK(3,2,10)+SEGK(3,2,11)+
     1    SEGK(4,2,10)+SEGK(4,2,11)+
     1    SEGK(5,2,10)+SEGK(5,2,11)+
     1    SEGK(6,2,10)+SEGK(6,2,11)+
     1    SEGK(1,3,10)+SEGK(1,3,11)+
     1    SEGK(2,3,10)+SEGK(2,3,11)+
     1    SEGK(3,3,10)+SEGK(3,3,11)+
     1    SEGK(4,3,10)+SEGK(4,3,11)+
     1    SEGK(5,3,10)+SEGK(5,3,11)+
     1    SEGK(6,3,10)+SEGK(6,3,11)+
     1    SEGK(2,4,10)+SEGK(2,4,11)+
     1    SEGK(3,4,10)+SEGK(3,4,11)+
     1    SEGK(4,4,10)+SEGK(4,4,11)+
     1    SEGK(5,4,10)+SEGK(5,4,11)+
     1    SEGK(6,4,10)+SEGK(6,4,11)+
     1    SEGK(2,5,10)+SEGK(2,5,11)+
     1    SEGK(3,5,10)+SEGK(3,5,11)+
     1    SEGK(4,5,10)+SEGK(4,5,11)+
     1    SEGK(5,5,10)+SEGK(5,5,11)+
     1    SEGK(6,5,10)+SEGK(6,5,11)+
     1    SEGK(1,6,10)+SEGK(1,6,11)+
     1    SEGK(2,6,10)+SEGK(2,6,11)+
     1    SEGK(3,6,10)+SEGK(3,6,11)+
     1    SEGK(4,6,10)+SEGK(4,6,11)+
     1    SEGK(5,6,10)+SEGK(5,6,11)+
     1    SEGK(6,6,10)+SEGK(6,6,11))
        VMAT(12,6) = SCAMM*(
     1    RFKM(1,6,10,1+RCHOP(1,6),1)+RFKM(1,6,11,1+RCHOP(1,6),1)+
     1    RFKM(2,6,10,1+RCHOP(2,6),1)+RFKM(2,6,11,1+RCHOP(2,6),1)+
     1    RFKM(3,6,10,1+RCHOP(3,6),1)+RFKM(3,6,11,1+RCHOP(3,6),1)+
     1    RFKM(4,6,10,1+RCHOP(4,6),1)+RFKM(4,6,11,1+RCHOP(4,6),1)+
     1    RFKM(5,6,10,1+RCHOP(5,6),1)+RFKM(5,6,11,1+RCHOP(5,6),1)+
     1    RFKM(6,6,10,1+RCHOP(6,6),1)+RFKM(6,6,11,1+RCHOP(6,6),1))
C
        VMAT(12,7) = SCAMM*(
     1    RFKM(1,2,4,1,1)+RFKM(1,2,5,1,1)+RFKM(1,2,6,1,1)+
     1    RFKM(2,2,4,1,1)+RFKM(2,2,5,1,1)+RFKM(2,2,6,1,1)+
     1    RFKM(3,2,4,1,1)+RFKM(3,2,5,1,1)+RFKM(3,2,6,1,1)+
     1    RFKM(4,2,4,1,1)+RFKM(4,2,5,1,1)+RFKM(4,2,6,1,1)+
     1    RFKM(5,2,4,1,1)+RFKM(5,2,5,1,1)+RFKM(5,2,6,1,1)+
     1    RFKM(6,2,4,1,1)+RFKM(6,2,5,1,1)+RFKM(6,2,6,1,1))
        VMAT(12,8) = SCAMM*(
     1    SEGK(1,2,4)+SEGK(1,2,5)+SEGK(1,2,6)+
     1    SEGK(2,2,4)+SEGK(2,2,5)+SEGK(2,2,6)+
     1    SEGK(3,2,4)+SEGK(3,2,5)+SEGK(3,2,6)+
     1    SEGK(4,2,4)+SEGK(4,2,5)+SEGK(4,2,6)+
     1    SEGK(5,2,4)+SEGK(5,2,5)+SEGK(5,2,6)+
     1    SEGK(6,2,4)+SEGK(6,2,5)+SEGK(6,2,6)+
     1    SEGK(1,3,4)+SEGK(1,3,5)+SEGK(1,3,6)+
     1    SEGK(2,3,4)+SEGK(2,3,5)+SEGK(2,3,6)+
     1    SEGK(3,3,4)+SEGK(3,3,5)+SEGK(3,3,6)+
     1    SEGK(4,3,4)+SEGK(4,3,5)+SEGK(4,3,6)+
     1    SEGK(5,3,4)+SEGK(5,3,5)+SEGK(5,3,6)+
     1    SEGK(6,3,4)+SEGK(6,3,5)+SEGK(6,3,6)+
     1    SEGK(2,4,4)+SEGK(2,4,5)+SEGK(2,4,6)+
     1    SEGK(3,4,4)+SEGK(3,4,5)+SEGK(3,4,6)+
     1    SEGK(4,4,4)+SEGK(4,4,5)+SEGK(4,4,6)+
     1    SEGK(5,4,4)+SEGK(5,4,5)+SEGK(5,4,6)+
     1    SEGK(6,4,4)+SEGK(6,4,5)+SEGK(6,4,6)+
     1    SEGK(2,5,4)+SEGK(2,5,5)+SEGK(2,5,6)+
     1    SEGK(3,5,4)+SEGK(3,5,5)+SEGK(3,5,6)+
     1    SEGK(4,5,4)+SEGK(4,5,5)+SEGK(4,5,6)+
     1    SEGK(5,5,4)+SEGK(5,5,5)+SEGK(5,5,6)+
     1    SEGK(6,5,4)+SEGK(6,5,5)+SEGK(6,5,6)+
     1    SEGK(1,6,4)+SEGK(1,6,5)+SEGK(1,6,6)+
     1    SEGK(2,6,4)+SEGK(2,6,5)+SEGK(2,6,6)+
     1    SEGK(3,6,4)+SEGK(3,6,5)+SEGK(3,6,6)+
     1    SEGK(4,6,4)+SEGK(4,6,5)+SEGK(4,6,6)+
     1    SEGK(5,6,4)+SEGK(5,6,5)+SEGK(5,6,6)+
     1    SEGK(6,6,4)+SEGK(6,6,5)+SEGK(6,6,6))
        VMAT(12,9) = SCAMM*(
     1    RFKM(1,6,4,1+RCHOP(1,6),1)+RFKM(1,6,5,1+RCHOP(1,6),1)+
     1     RFKM(1,6,6,1+RCHOP(1,6),1)+
     1    RFKM(2,6,4,1+RCHOP(2,6),1)+RFKM(2,6,5,1+RCHOP(2,6),1)+
     1     RFKM(2,6,6,1+RCHOP(2,6),1)+
     1    RFKM(3,6,4,1+RCHOP(3,6),1)+RFKM(3,6,5,1+RCHOP(3,6),1)+
     1     RFKM(3,6,6,1+RCHOP(3,6),1)+
     1    RFKM(4,6,4,1+RCHOP(4,6),1)+RFKM(4,6,5,1+RCHOP(4,6),1)+
     1     RFKM(4,6,6,1+RCHOP(4,6),1)+
     1    RFKM(5,6,4,1+RCHOP(5,6),1)+RFKM(5,6,5,1+RCHOP(5,6),1)+
     1     RFKM(5,6,6,1+RCHOP(5,6),1)+
     1    RFKM(6,6,4,1+RCHOP(6,6),1)+RFKM(6,6,5,1+RCHOP(6,6),1)+
     1     RFKM(6,6,6,1+RCHOP(6,6),1))
C
C Medulla - MCD = OMCD+IMCD
        VMAT(13,1) = SCV*RFVM(1,11,1,1)
        VMAT(13,2) = SCV*(
     1   SEGV(1,11)+SEGV(2,11)+SEGV(3,11)+
     1   SEGV(4,11)+SEGV(5,11)+SEGV(6,11)+
     1   SEGV(1,12)+SEGV(2,12)+SEGV(3,12)+
     1   SEGV(4,12)+SEGV(5,12)+SEGV(6,12))
C        VMAT(13,3) = VMAT(13,1) - VMAT(13,2)
        VMAT(13,3) = SCV*RFVM(1,12,1+RCHOP(1,12),1)
C
        VMAT(13,4) = SCAMM*(
     1   RFKM(1,11,10,1,1)+RFKM(1,11,11,1,1))
        VMAT(13,5) = SCAMM*(
     1    SEGK(1,11,10)+SEGK(1,11,11)+
     1    SEGK(2,11,10)+SEGK(2,11,11)+
     1    SEGK(3,11,10)+SEGK(3,11,11)+
     1    SEGK(4,11,10)+SEGK(4,11,11)+
     1    SEGK(5,11,10)+SEGK(5,11,11)+
     1    SEGK(6,11,10)+SEGK(6,11,11)+
     1    SEGK(1,12,10)+SEGK(1,12,11)+
     1    SEGK(2,12,10)+SEGK(2,12,11)+
     1    SEGK(3,12,10)+SEGK(3,12,11)+
     1    SEGK(4,12,10)+SEGK(4,12,11)+
     1    SEGK(5,12,10)+SEGK(5,12,11)+
     1    SEGK(6,12,10)+SEGK(6,12,11))
C        VMAT(13,6) = VMAT(13,4) - VMAT(13,5)
        VMAT(13,6) = SCAMM*(
     1    RFKM(1,12,10,1+RCHOP(1,12),1)+RFKM(1,12,11,1+RCHOP(1,12),1))
C
        VMAT(13,7) = SCAMM*(
     1    RFKM(1,11,4,1,1)+RFKM(1,11,5,1,1)+RFKM(1,11,6,1,1))
        VMAT(13,8) = SCAMM*(
     1    SEGK(1,11,4)+SEGK(1,11,5)+SEGK(1,11,6)+
     1    SEGK(2,11,4)+SEGK(2,11,5)+SEGK(2,11,6)+
     1    SEGK(3,11,4)+SEGK(3,11,5)+SEGK(3,11,6)+
     1    SEGK(4,11,4)+SEGK(4,11,5)+SEGK(4,11,6)+
     1    SEGK(5,11,4)+SEGK(5,11,5)+SEGK(5,11,6)+
     1    SEGK(6,11,4)+SEGK(6,11,5)+SEGK(6,11,6)+
     1    SEGK(1,12,4)+SEGK(1,12,5)+SEGK(1,12,6)+
     1    SEGK(2,12,4)+SEGK(2,12,5)+SEGK(2,12,6)+
     1    SEGK(3,12,4)+SEGK(3,12,5)+SEGK(3,12,6)+
     1    SEGK(4,12,4)+SEGK(4,12,5)+SEGK(4,12,6)+
     1    SEGK(5,12,4)+SEGK(5,12,5)+SEGK(5,12,6)+
     1    SEGK(6,12,4)+SEGK(6,12,5)+SEGK(6,12,6))
C        VMAT(13,9) = VMAT(13,7) - VMAT(13,8)
        VMAT(13,9) = SCAMM*(
     1    RFKM(1,12,4,1+RCHOP(1,12),1)+RFKM(1,12,5,1+RCHOP(1,12),1)+
     1    RFKM(1,12,6,1+RCHOP(1,12),1))
C Medulla - Nephrons
        VMAT(14,1) = VMAT(12,1) + VMAT(13,1)
        VMAT(14,2) = VMAT(12,2) + VMAT(13,2)
        VMAT(14,3) = VMAT(12,3) + VMAT(13,3)
C
        VMAT(14,4) = VMAT(12,4) + VMAT(13,4)
        VMAT(14,5) = VMAT(12,5) + VMAT(13,5)
        VMAT(14,6) = VMAT(12,6) + VMAT(13,6)
C
        VMAT(14,7) = VMAT(12,7) + VMAT(13,7)
        VMAT(14,8) = VMAT(12,8) + VMAT(13,8)
        VMAT(14,9) = VMAT(12,9) + VMAT(13,9)
C
        WRITE (306, 110)
  110   FORMAT(24X,' Volume - Fv',24X,'Ammonia - Fk',/,
     1    12X,'    Entry   ','    Flux    ','    Exit    ',
     1    '    Entry   ','    Flux    ','    Exit    ','    Gen     ')
        WRITE (306,111)
  111   FORMAT('   Cortex   ')
        WRITE (306,112) (VMAT(1,J),J=1,6)
        WRITE (306,113) (VMAT(2,J),J=1,6)
        WRITE (306,114) (VMAT(3,J),J=1,6)
        WRITE (306,115) (VMAT(4,J),J=1,6)
        WRITE (306,116) (VMAT(5,J),J=1,6),
     1   (VMAT(1,6)+VMAT(5,6)) - (VMAT(1,4)+VMAT(5,4))
  112   FORMAT('     Cap    ',6(3X,F6.3,3X))
  113   FORMAT('     PCT    ',6(3X,F6.3,3X))
  114   FORMAT('     DCT    ',6(3X,F6.3,3X))
  115   FORMAT('     CNT    ',6(3X,F6.3,3X))
  116   FORMAT('  Nephrons  ',7(3X,F6.3,3X))
        WRITE (306,121)
  121   FORMAT('   Med Ray  ')
        WRITE (306,122) (VMAT(6,J),J=1,6)
        WRITE (306,123) (VMAT(7,J),J=1,6)
        WRITE (306,124) (VMAT(8,J),J=1,6)
        WRITE (306,125) (VMAT(9,J),J=1,6)
        WRITE (306,126) (VMAT(10,J),J=1,6),
     1   (VMAT(6,6)+VMAT(10,6)) - (VMAT(6,4)+VMAT(10,4))
  122   FORMAT('     Cap    ',6(3X,F6.3,3X))
  123   FORMAT('    MRPST   ',6(3X,F6.3,3X))
  124   FORMAT('    AHLc    ',6(3X,F6.3,3X))
  125   FORMAT('     CCD    ',6(3X,F6.3,3X))
  126   FORMAT('  Nephrons  ',7(3X,F6.3,3X))
        WRITE (306,131)
  131   FORMAT('   Medulla  ')
        WRITE (306,132) (VMAT(11,J),J=1,6)
        WRITE (306,133) (VMAT(12,J),J=1,6)
        WRITE (306,134) (VMAT(13,J),J=1,6)
        WRITE (306,135) (VMAT(14,J),J=1,6),
     1   (VMAT(11,6)+VMAT(14,6)) - (VMAT(11,4)+VMAT(14,4))
  132   FORMAT('    VR      ',6(3X,F6.3,3X))
  133   FORMAT('    LOH     ',6(3X,F6.3,3X))
  134   FORMAT('    MCD     ',6(3X,F6.3,3X))
  135   FORMAT('  Nephrons  ',7(3X,F6.3,3X))
C
        WRITE (306,141) (VMAT(1,J)+VMAT(6,J)+VMAT(11,J),J=1,6)
  141   FORMAT(/,'All Vessels ',6(3X,F6.3,3X))
C
C
        WRITE (306, 210)
  210   FORMAT(//,24X,'Total CO2-Fk',/,12X,
     1    '    Entry   ','    Flux    ','    Exit    ','    Gen     ')
        WRITE (306,211)
  211   FORMAT('   Cortex   ')
        WRITE (306,212) (VMAT(1,J),J=7,9)
        WRITE (306,213) (VMAT(2,J),J=7,9)
        WRITE (306,214) VMAT(3,7),VMAT(3,8),VMAT(3,9)
        WRITE (306,215) VMAT(4,7),VMAT(4,8),VMAT(4,9)
        WRITE (306,216) (VMAT(5,J),J=7,9),
     1   (VMAT(1,9)+VMAT(5,9)) - (VMAT(1,7)+VMAT(5,7))
  212   FORMAT('     Cap    ',3(2X,F7.3,3X))
  213   FORMAT('     PCT    ',3(2X,F7.3,3X))
  214   FORMAT('     DCT    ',3(2X,F7.3,3X))
  215   FORMAT('     CNT    ',3(2X,F7.3,3X))
  216   FORMAT('  Nephrons  ',4(2X,F7.3,3X))
        WRITE (306,221)
  221   FORMAT('   Med Ray  ')
        WRITE (306,222) (VMAT(6,J),J=7,9)
        WRITE (306,223) (VMAT(7,J),J=7,9)
        WRITE (306,224) (VMAT(8,J),J=7,9)
        WRITE (306,225) (VMAT(9,J),J=7,9)
        WRITE (306,226) (VMAT(10,J),J=7,9),
     1   (VMAT(6,9)+VMAT(10,9)) - (VMAT(6,7)+VMAT(10,7))
  222   FORMAT('     Cap    ',3(2X,F7.3,3X))
  223   FORMAT('    MRPST   ',3(2X,F7.3,3X))
  224   FORMAT('    AHLc    ',3(2X,F7.3,3X))
  225   FORMAT('     CCD    ',3(2X,F7.3,3X))
  226   FORMAT('  Nephrons  ',4(2X,F7.3,3X))
        WRITE (306,231)
  231   FORMAT('   Medulla  ')
        WRITE (306,232) (VMAT(11,J),J=7,9)
        WRITE (306,233) (VMAT(12,J),J=7,9)
        WRITE (306,234) (VMAT(13,J),J=7,9)
        WRITE (306,235) (VMAT(14,J),J=7,9),
     1   (VMAT(11,9)+VMAT(14,9)) - (VMAT(11,7)+VMAT(14,7))
  232   FORMAT('    VR      ',3(2X,F7.3,3X))
  233   FORMAT('    LOH     ',3(2X,F7.3,3X))
  234   FORMAT('    MCD     ',3(2X,F7.3,3X))
  235   FORMAT('  Nephrons  ',4(2X,F7.3,3X))
C
        WRITE (306,241) (VMAT(1,J)+VMAT(6,J)+VMAT(11,J),J=7,9)
  241   FORMAT(/,'All Vessels ',3(2X,F7.3,3X))
C
        RETURN
        END
