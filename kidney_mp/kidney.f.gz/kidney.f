	PROGRAM KIDNEY
C
C 9/11/20 Program has been modified so that capillaries within MR and Cortex return blood 
C  with solute concentrations identical to those of the interstitium.  In this, the IS 
C  concentrations become model unknowns.
C
C 9/3/15 PROGRAM TO MERGE NEPHRON WITH VASC TO SOLVE FOR MEDULLARY INTERSITITAL PROFILE 
C  Interstitial concentrations and pressures are determined on a coarse grid to permit 
C  a tractable number of variables.  These grid values are refined by linear interpolation.
C At this level of the program, there will only be archived variables, plus the necessary
C  CS variables, which are updated on their grids.
C
C **FOR THIS PROGRAM TO WORK, VARIABLES OMCHOP AND IMCHOP MUST BE WELL-DEFINED
C    OMCHOP = CHOP(PST) + CHOP(sDHL) (=CHOP(lDHLu) = CHOP(AHLm) = CHOP(OMCD)
C    IMCHOP = CHOP(lDHLl) = CHOP(tAHL) = CHOP(IMCD)
C    MRCHOP = CHOP(AHLc) = CHOP(CCD)
C
C Boundary dat, specified and variable, will be set at the top level (kidney) and placed
C   in archive variables.
C                        Lumen (Init)            IS (Init)            IS (End)
C       SFPCT,JMPCT         KBSET            KBSET (Cortex)         KBSET (Cortex)
C       SFPST,JMPST           -              KGAM (OM - init)       KGAM (OM - mid)
C       sDHL,lDHLu            -              KGAM (OM - mid)        KGAM (OM - end)
C       lDHLl,tAHL            -              KGAM (OM - end)        KGAM (IM)
C       AHLm                  -              KGAM (OM - end)        KGAM (MR - end)
C       AHLc                  -              KGAM (MR - end)        KGAM (MR - init)
C       DCT,CNT               -              KBSET (Cortex)         KBSET (Cortex)
C       CCT                   -              KGAM (MR - init)       KGAM (MR - end)
C       OMCT                  -              KGAM (MR - end)        KGAM (OM - end)
C       IMCT                  -              KGAM (OM - end)        KGAM (IM - end)
C
C       OMDVR,OMAVR (IS)    KBSET            KGAM (OM - init)       KGAM (OM - end)
C       OIDVR,OIAVR         KBSET            KGAM (MR - end)        KGAM (OM - end)
C       IMDVR,IMAVR           -              KGAM (OM - end)        KGAM (IM)
C       MRDVR,MRAVR (IS)    KBSET            KGAM (MR - init)       KGAM (MR - end)
C
C 12/29/13  PROGRAM TO MERGE PN WITH DN TO CREATE A FULL NEPHRON
C Novel additions are 
C  Solving the 6 nephrons through dct,
C    then rapid mixing to enter a common CNT (no CO2 hydration/dehydration at the mixing point)
C  Entering CNT hydrostatic pressure will depend upon end-IMCD outlet pressure (nominally 0 mmHg)
C  Since CNT pressure depends upon CNT flow, it depends upon flow delivered by each nephron, 
C    so that nephrons are weakly coupled.
C  Since proximal nephron flux is pressure-dependent, initial PCT flow and pressure are 
C    subject to TGF and matching CNT inlet pressure, in all 13 global variables.
C  
C  Calculation plan: 
C  SFPCT -> SFPST -> SDHL -> AHLm -> AHLc -> DCT
C  JMPCT -> JMPST -> LDHLu -> LDHLl(2-6) -> tAHL(2-6) -> AHLm(2-6) -> AHLc(2-6) -> DCT(2-6)
C  Merged DCT -> CNT -> CCD -> OMCD -> IMCD
C 
C Carbonic Anhydrase
C   Clearly less in PST; there is some in sDHL; largely absent in IM.
C   Model parameters: 1% of full catalysis in PST, sDHL, and lDHLu; absent (0.01%) in lDHLl and tAHL
C   Will assume full catalysis in IS (in view of proximity to RBC).
C
C 12/22/12 - ARCHIVAL VARIABLES ADDED IN ANTICIPATION OF MULTIPLE NEPHRONS
C THERE ARE TWO MEASURES OF DISTANCE ALONG THE NEPHRON:
C    X IS AN INTEGER VARIABLE, AND WILL NOW BE ZEROED WITH EACH SEGMENT
C    DIST IS A REAL VARIABLE THAT TRACKS DISTANCE ALONG THE NEPHRON
C    ALTHOUGH THIS WILL BECOME AMBIGUOUS AS DIFFERENT LENGTHS COALESCE IN CNT
C
C 2/8/13 - TGF ADJUSTS SNGFR ACCORDING TO MACULA DENSA [CL-]i 
C    AND EARLY PT PRESSURE ACCORDING TO DCT PRESSURE.
C
C
C LOCAL VARIABLES
C
	INTEGER SOLS,T,X,COUNT,EXP,
     1    CHOP,OMCHOP,IMCHOP,MRCHOP,
     1    SLICE,OMSLC,IMSLC,MRSLC
C
C       SOLS-   NUMBER OF SOLUTES
C       T-      INDEX FOR OLD (=1) OR NEW (=2) TIME STEP
C       COUNT-  NUMBER OF EXPT. BEING SIMULATED
C       EXP-    TOTAL NUMBER OF EXPTS. IN THE RUN
C	X-	INDICATES SPATIAL STEP
C	CHOP-	SPATIAL CHOP OF TUBULE
C       OMCHOP,IMCHOP,MRCHOP - REGIONAL CHOP FOR OM, IM AND MR
C       SLICE-  OM+IM+MR DISCRETIZATION OF GUESSES 
C               (REFINED TO OMCHOP+IMCHOP+MRCHOP BY LINEAR INTERPOLATION)
C               GAMMA VECTOR IS BASED ON SLICE
C       OMSLC,IMSLC,MRSLC - REGIONAL INTERSTITIAL CHOP FOR OM, IM AND MR
C		In the original program, these were 2, 5, and 1.
C
        CHARACTER*8 SOL(16),ALABL(16)
        CHARACTER*12 NIL,VMAT(16,91)
C
C FOR THE BASELINE CONFIRGURATION:
C  SLICE DEMARCATIONS AT 0 - 7 MM FROM OM TO PAPILLA
C Interstitial unknows are pressure and concentration at 3 points in OM, 5 points
C  in IM, and two points in MR.  The x=0 point in OM abuts PST; there is a second
C  x=0 point in OM that is identified with MR=2mm, and this abuts AHL and OMCD.
C  Within MR, the x=0 point abuts AHLc and CCD.
C
C 8/3/20 - Expansion of the problem with cortical capillaries -
C   MR perfusion is lateral (not axial) with systemic perfusion conditions,
C   and capillary equilibration of interstitial concentrations (convective uptake).
C   Cortex interstitial concentrations become a model variable as a well-mixed compartment.
C
C SPECIFIED BOUNDARY DATA
C
        DOUBLE PRECISION
     1   CSMR(15,201,2),CSOM(15,101,2),CSIM(15,501,2),
     1   PSMR(201,2),PSOM(101,2),PSIM(501,2),
     1   CSGAM(15,91),PSGAM(91),KEPSI,FVCGAM(91),FVCMR(201,2),
     1   PS0(3),IMPM0(2),IMPS0(3),CM0(15,2),CS0(16,3), 
     1   FVC0(4),PC0(4),IMPC0(4),HCT0(4),CC0(16,4)
C
C       CSMR,CSOM,CSIM- CS CONCENTRATIONS AT GRID POINTS (FOR EXPORT TO NEPHRON AND VASC)
C       PSMR,PSOM,PSIM- PS VALUES AT GRID POINTS (FOR EXPORT TO NEPHRON AND VASC)
C       CSGAM-  GUESS CS CONCENTRATIONS AT SLICE BOUNDARIES
C       PSGAM-  GUESS PS VALUES AT SLICE BOUNDARIES
C       KEPSI-   ERROR TOLERANCE FOR THE KIDNEY ITERATIONS
C       FVCGAM- GUESS AT CAPILLARY VOUME UPTAKE AT SLICE BOUNDARIES
C       FVCMR-  FVC VALUES AT GRID POINTS WITHIN MR
C
C	FVMO(1) and FVM0(2)- SFPCT and JMPCT(2) flows for all SF and JM(2) nephrons
C	PSO- 	SFPCT, JMPCT, and DCT/CNT vascular pressures (uniform)
C	IMPM0- filtered impermeant osmolality
C	IMPS0- vascular impermeant osmolality for SFPCT, JMPCT, and DCT/CNT (mM)
C	CM0-	glomerular filtrate composition
C	CS0-	vascular plasma composition for SFPCT, JMPCT, and DCT/CNT
C	CSMR-	cortical composition within medullary ray
C
C	FVC0-	capillary plasma flow for individual OMDVR, OIDVR, and MRDVR
C	PC0-	capillary pressures
C	IMPC0- 	capillary protein concentration (gm/dl)
C	HCT0-	hematocrits
C	CC0-	capillary solute composition
C
C VARIABLES UTILIZED IN THE GEN AND VGEN SUBROUTINES
C
        DOUBLE PRECISION
     1    OMDIST(501),IMDIST(501),MRDIST(501),
     1    OMJVMS(501),OMJKMS(16,501),
     1    IMJVMS(501),IMJKMS(16,501),
     1    MRJVMS(501),MRJKMS(16,501),
     1    MEDJVMS(91),MEDJKMS(16,91),SEGV(6,14),SEGK(6,14,16),
     1    OMJVCS(501),OMJKCS(16,501),
     1    IMJVCS(501),IMJKCS(16,501),
     1    MRJVCS(501),MRJKCS(16,501),
     1    MEDJVCS(91),MEDJKCS(16,91),VSEGV(9,4),VSEGK(9,4,16)
C
        INTEGER IN,IG(1008),IP(1008),
     1   NSLC,NCOR,KSLC(91),NTGF,NPR,NVOL,KVOL(91),NSOL,KSOL(15)
	DOUBLE PRECISION 
     1    PHI(1008),GAMMA(1008),DGAM(1008),PPHI(1008),
     1    PREMAX,MAXPHI,DELGAM(1008),NDERIV(1008,1008),
     1    RPHI(1008),RGAMMA(1008),RDERIV(1008,1008)
C
C       PHI-    ERROR VECTOR- TO BE ZEROED VIA NEWTON ITERATION
C       GAMMA-  VARIABLE VECTOR
C       DGAM-   VARIABLE INCREMENT TO COMPUTE NUMERICAL DERIVATIVE
C       PPHI-   ERROR VECTOR AT GAMMA + DGAM
C       NDERIV- NUMERICAL DERIVATIVE OF PHI WITH RESPECT TO GAMMA
C       PREMAX- PRIOR MAXPHI TO ASSESS REUSE OF THE JACOBIAN
C       MAXPHI- MAXIMUM COMPONENT OF THE PHI VECTOR
C	DELGAM-	CORRECTIONS TO THE GAMMA VECTOR COMPUTED BY LES
C       RPHI-   REDUCED PHI WITH ENTRY J EQUAL TO PHI(IP(J))
C       RGAMMA- REDUCED GAMMA WITH ENTRY K EQUAL TO GAMMA(IG(K))
C       RDERIV- REDUCED JACOBIAN WITH ENTRY (J,K) EQUAL TO NDERIV(IP(J),IG(K))
C
C KEY TO INDICES:
C  6 nephrons: SF (INEPH = 1) plus 5 JM (INEPH = 2-6)
C    SFPCT and SFPST in series with SDHL
C    JMPCT and JMPST in series with LDHLu and LDHLl
C  LDHLu will be restricted to OM and LDHLl to IM
C
C Plan for 24000 SF nephrons (@30 nl/min -> 720 mul/min) 
C    12400 JM nephrons (@60 nl/min -> 720 mul/min) 
C     Of the 12000 JM, turns can parallel CD coning:
C    1 mm 6400
C    2 mm 3200
C    3 mm 1600
C    4 mm  800
C    5 mm  400
C
C Segment numbers (ISEG)
C      1- PCT
C      2- PST
C      3- sDHL, lDHLu
C      4- lDHLl
C      5- tAHL
C      6- AHLm
C      7- AHLc
C      8- DCT
C      9- CNT
C      10-CCD
C      11-OMCD
C      12-IMCD
C      13-PSTMR
C
C ARCHIVED NEPHRON VARIABLES
C
	INTEGER 
     1   RX(6,14), RCHOP(6,14)
C
C GENERAL PARAMETERS
	DOUBLE PRECISION
     1   RDIST(6,14), REPSI(6,14), RL0(6,14),
     1   RL(6,14,501,2), RKHY(6,14,5), RKDHY(6,14,5), RBCO2(6,14,3)
C
C LUMINAL AND PERITUBULAR PARAMETERS
	DOUBLE PRECISION
     1   RVM(6,14,501,2), RPM(6,14,501,2), RCM(6,14,15,501,2),
     1   RIMPM(6,14,501,2), RLCHM(6,14,501), RXM(6,14,15,501),
     1   RVS(6,14,501,2), RPS(6,14,501,2), RCS(6,14,15,501,2),
     1   RIMPS(6,14,501,2), RLCHS(6,14,501), RXS(6,14,15,501),
     1   RTL(6,14), RDX(6,14), RRM0(6,14),
     1   RMUM(6,14), RETA(6,14), RSM(6,14,501,2),
     1   RAM(6,14,501,2), RFVM(6,14,501,2), RFKM(6,14,16,501,2)
C
C INTERSPACE PARAMETERS
	DOUBLE PRECISION
     1   RAME(6,14), RAE0(6,14), RAE(6,14,501,2),
     1   RMUA(6,14), RCHVL0(6,14), RCHVL(6,14,501,2),
     1   RMUV(6,14), RLPME(6,14), RLPES(6,14),
     1   RSME(6,14,15), RSES(6,14,15), RHME(6,14,15),
     1   RHES(6,14,15), RVE(6,14,501,2), RPE(6,14,501,2),
     1   RCE(6,14,15,501,2), RLCHE(6,14,501), RXE(6,14,15,501),
     1   RFEVM(6,14,501,2), RFEKM(6,14,15,501,2), RFEVS(6,14,501,2),
     1   RFEKS(6,14,15,501,2), RCURE(6,14,501)
C
C CELL PARAMETERS
	DOUBLE PRECISION
     1   RAIE(6,14,3), RAMI(6,14,3), RAIS(6,14,3),
     1   RAI0(6,14,3), RCLVL0(6,14,3), RIMP0(6,14,3),
     1   RCLVL(6,14,3,501,2), RZIMP(6,14,3), RTBUF(6,14,3),
     1   RPKB(6,14,3), RCBUF(6,14,3,501,2), RHCBUF(6,14,3,501,2),
     1   RLPMI(6,14,3), RLPIS(6,14,3), RSMI(6,14,3,15),
     1   RSIS(6,14,3,15), RHMI(6,14,3,15), RHIS(6,14,3,15),
     1   RLMI(6,14,3,15,15), RLIS(6,14,3,15,15), RATMI(6,14,3,15,501),
     1   RATIS(6,14,3,15,501), RATIE(6,14,3,15,501), RVI(6,14,3,501,2),
     1   RPI(6,14,3,501,2), RCI(6,14,3,15,501,2), RIMP(6,14,3,501),
     1   RLCHI(6,14,3,501), RXI(6,14,3,15,501), RFIVM(6,14,3,501,2),
     1   RFIKM(6,14,3,15,501,2), RFIVS(6,14,3,501,2), 
     1   RFIKS(6,14,3,15,501,2), RCURI(6,14,3,501), 
     1   RJV(6,14,3,501,2), RJK(6,14,3,15,501,2)
C
C SPECIAL TRANSPORTERS
	CHARACTER*1 RISOFM(6,14)
	DOUBLE PRECISION
     1   RNP(6,14,3), RKNPN(6,14,3), RKNPK(6,14,3),
     1   RKNH4(6,14,3), RNPHK(6,14,3), RLHP(6,14,3),
     1   RXIHP(6,14,3), RXHP(6,14,3), RNAE1(6,14,3),
     1   RNTSC(6,14,3), RNNHE3(6,14,3), RJNAK(6,14,3,3,501,2),
     1   RJHK(6,14,3,501,2), RJHP(6,14,3,501,2), RJAE1(6,14,3,501,2),
     1   RJTSC(6,14,3,501,2), RJNHE3(6,14,3,3,501,2), RQIAMM(6,14),
     1   RNNKCC(6,14,3), RNKCL(6,14,3), RJNKCC(6,14,3,4,501,2),
     1   RJKCC(6,14,3,3,501,2)
C
C TORQUE AND COMPLIANCE VARIABLES
	DOUBLE PRECISION
     1   RTQM(6,14,501,2), RRM(6,14,501,2), RMUR(6,14), RSCALMI(6,14),
     1   RSCALIS(6,14), RVM0(6,14), RAM0(6,14), RTQM0(6,14),
     1   RLHP0(6,14,3), RNP0(6,14,3), RNNHE30(6,14,3), RLPMI0(6,14,3),
     1   RLPIS0(6,14,3), RHMI0(6,14,3,15), RHIS0(6,14,3,15),
     1   RLMI0(6,14,3,15,15), RLIS0(6,14,3,15,15), RQIAMM0(6,14),
     1   RMVL(6,14), RMVD(6,14), RRMT0(6,14)
C
C TGF VARIABLES: STARTING WITH THE BASELINE SNGFR, 
C   IT IS ADJUSTED ACCORDING TO MACULA DENSA CELL [CL-] 
C INITIAL PT PRESSURE IS ADJUSTED ACCORDING TO A DISTAL NEPHRON RESISTANCE
C
	DOUBLE PRECISION 
     1   FVM0(2),AFVM(6),DFVM(6),AFVM0(2),DFVM0(2),MDCL(2),DMDCL(2),
     1   TGGAM(15),TGPHI(15),TGPPHI(15),TGEPSI,TGDERIV(15,15),
     1   TGDGAM(15),TGDELG(15),RTGPHI(15),DNR,RGUESS(60,25)
C	
C	FVM0-	SNGFR READ FROM BOUND.DAT-INDEX FOR SF (1) OR JM (2)
C	AFVM-	FIXED COMPONENT OF FVM0
C	DFVM-	COMPONENT OF FVM0 THAT CAN BE MODULATED BY TGF
C	MDCL-	MACULA DENSA CL- REFERENCE CONCENTRATION
C	DMDCL-	MACULA DENSA CL- RANGE YIELDING DFVM
C	TGGAM-	TG FEEDBACK VARIABLE (CHANGE IN FV)
C               1-      SF FVM(1)/FVM0(1)
C               2-      SF PM(1)
C               2J-1-   JM FVM(1)/FVM0(2), J=2,6
C               2J-     JM PM(1)
C               13-     CNT PM(1)
C	TGPHI-	TG FEEDBACK RELATION
C               2J-1-   TGF RELATIONS, J=1,6
C         TGPHI(2J-1) = FVM(0) - AFVM - (DFVM / DMDCL) * [MDCL - CIAHL]
C               2J-     MATCHING PRESSURES AT CNT ENTRY 
C         TGPHI(2J) = PM-END-DCT = PM-CNT
C               13-   IMCD PM(L) - DNR
C  old    TGPHI(13) = CNT PM(1) - DNR*FVMCNT
C	TGEPSI-	TG FEEDBACK ERROR
C	TGDERIV-	TG FEEDBACK JACOBIAN 
C	TGDGAM-	TG FEEDBACK VARIABLE INCREMENT
C	TGDELG-	TG FEEDBACK VARIABLE NEWTON CORRECTION
C
C VASC:
C Plan for 36000 OMDVR = 24000 sDVR + 12000 lDVR ~ about 3x JM glomeruli
C           7200 MRDVR (DVR from 24000 SF glom = 72000, so this is 10%)  
C Plan for 72000 OMAVR, 48000 IMAVR, 14400 MRAVR; AVR are 2x the DVR number
C  OM and IM DVR derive from 12000 JM nephrons; MR DVR from 2400 SF nephrons
C  Of the IM vessels, turns parallel those of the nephron
C         IMDVR       IMAVR
C    1 mm  6000       12000
C    2 mm  3000        6000
C    3 mm  1500        3000
C    4 mm   750        1500
C    5 mm   375         750
C
C PROGRAM TO BUILD A VAS RECTUM:
C   OUTER MEDULLARY 1,2, descending 1 or 2 mm; 
C   INNER MEDULLARY 3,7, descending 1,...,5 mm into IM;
C   AND MEDULLARY RAY, 8, 2 mm in length.
C  NOTE THAT OMDVR FEEDING IMDVR IS DIFFERENT FROM OMDVR WHICH TURNS IN OM
C  VESSEL 9 CORRESPONDS TO CORTICAL PERITUBULAR CAPILLARIES
C
        DOUBLE PRECISION RADVR(9),RDNUM(9),RANUM(9)
C       RADVR- RATIO OF AVR NUMBER TO DVR NUMBER FOR EACH VESSEL
C       RDNUM- NUMBER OF EACH CLASS OF DVR
C       RANUM- NUMBER OF EACH CLASS OF AVR
C
	INTEGER 
     1   RVX(9,4), RVCHOP(9,4)
C PARAMETERS
	DOUBLE PRECISION
     1   RVEPSI(9,4),RVDIST(9,4),RVKHY(9,4),RVKDHY(9,4),
     1   RVDX(9,4),RVETA(9,4),RCL(9,4),RRC0(9,4),RMUC(9,4),
     1   RLPCS(9,4),RSCS(9,4,15),RLCS(9,4,15),RHCS(9,4,15),
     1   RLPCSE(9,4),RSCSE(9,4,15),RLCSE(9,4,15),RHCSE(9,4,15),
     1   RLPCSI(9,4),RSCSI(9,4,15),RLCSI(9,4,15),RHCSI(9,4,15)
C VARIABLES
	DOUBLE PRECISION
     1   RVVS(9,4,501,2),RVPS(9,4,501,2),RVCS(9,4,16,501,2),
     1   RVIMPS(9,4,501,2),RVLCHS(9,4,501),RVXS(9,4,15,501),
     1   RVC(9,4,501,2),RPC(9,4,501,2),RCC(9,4,31,501,2),
     1   RIMPC(9,4,501,2),RLCHC(9,4,501),RXC(9,4,15,501),
     1   RSAT(9,4,501,2),RCCN(9,4,501,2),
     1   RCCX(9,4,501,2),RCCY(9,4,501,2),RPOX(9,4,501,2),
     1   RSC(9,4,501,2),RAC(9,4,501,2),RFVC(9,4,501,2),
     1   RFKC(9,4,31,501,2),RFVCS(9,4,501,2),RFKCS(9,4,16,501,2),
     1   RFVCSE(9,4,501,2),RFKCSE(9,4,16,501,2),RFVCSI(9,4,501,2),
     1   RFKCSI(9,4,16,501,2),RHCTC(9,4,501,2),RFBC(9,4,501,2)
C
C	
	DOUBLE PRECISION SW,PTOL
	INTEGER PR,PFL
C
C	SW-	ERROR SWITCH FOR LES
C	PTOL-	PIVOT TOLERANCE
C	PR-	NUMBER OF THE PIVOT ROW FOR EACH COLUMN
C	PFL-	PIVOT FLAG SHOWING ROWS FOR WHICH PIVOTS HAVE BEEN CHOSEN
C
	DIMENSION PR(1008),PFL(1008)
C
C
        DATA RVVS /36072*0.D0/,RVIMPS/36072*0.D0/
C
        OPEN (301,FILE='kguess.dat')
        OPEN (302,FILE='kparam.dat')
        OPEN (303,FILE='kguess.new')
        OPEN (304,FILE='kphi.dat')
        OPEN (305,FILE='kjac.dat')
        OPEN (306,FILE='ammonia.sum')
C
	OPEN (10,FILE='nephron/lumen.dat')
	OPEN (11,FILE='nephron/blood.dat')
	OPEN (12,FILE='nephron/xy.co2')
	OPEN (13,FILE='nephron/tgf.dat')
	OPEN (14,FILE='nephron/guess.dat')
	OPEN (15,FILE='nephron/guess.new')
	OPEN (16,FILE='nephron/medjms.dat')
	OPEN (17,FILE='nephron/torque.dat')
	OPEN (18,FILE='nephron/xy.dat')
	OPEN (19,FILE='nephron/medjms.sum')
	OPEN (400,FILE='nephron/ar.dat')
C
	OPEN (160,FILE='nephron/sfpct/sfpctparam.dat')
	OPEN (161,FILE='nephron/sfpct/sfpctresult.dat')
	OPEN (162,FILE='nephron/sfpct/sfpctbound.dat')
	OPEN (163,FILE='nephron/sfpct/sfpctptpick.dat')
	OPEN (164,FILE='nephron/sfpct/sfpctguess.dat')
	OPEN (165,FILE='nephron/sfpct/sfpctguess.new')
	OPEN (166,FILE='nephron/sfpct/sfpctptim.dat')
	OPEN (167,FILE='nephron/sfpct/sfpctfluxes.dat')
	OPEN (168,FILE='nephron/sfpct/sfpctxy.qo2')
	OPEN (169,FILE='nephron/sfpct/sfpctpres.dat')
C
	OPEN (170,FILE='nephron/pstmr/pstmrparam.dat')
	OPEN (171,FILE='nephron/pstmr/pstmrresult.dat')
	OPEN (172,FILE='nephron/pstmr/pstmrbound.dat')
	OPEN (173,FILE='nephron/pstmr/pstmrptpick.dat')
	OPEN (174,FILE='nephron/pstmr/pstmrguess.dat')
	OPEN (175,FILE='nephron/pstmr/pstmrguess.new')
	OPEN (176,FILE='nephron/pstmr/pstmrptim.dat')
	OPEN (177,FILE='nephron/pstmr/pstmrfluxes.dat')
	OPEN (178,FILE='nephron/pstmr/pstmrxy.qo2')
	OPEN (179,FILE='nephron/pstmr/pstmrpres.dat')
C
	OPEN (150,FILE='nephron/sfpst/sfpstparam.dat')
	OPEN (151,FILE='nephron/sfpst/sfpstresult.dat')
	OPEN (152,FILE='nephron/sfpst/sfpstbound.dat')
	OPEN (153,FILE='nephron/sfpst/sfpstptpick.dat')
	OPEN (154,FILE='nephron/sfpst/sfpstguess.dat')
	OPEN (155,FILE='nephron/sfpst/sfpstguess.new')
	OPEN (156,FILE='nephron/sfpst/sfpstptim.dat')
	OPEN (157,FILE='nephron/sfpst/sfpstfluxes.dat')
	OPEN (158,FILE='nephron/sfpst/sfpstxy.qo2')
	OPEN (159,FILE='nephron/sfpst/sfpstpres.dat')
C
	OPEN (140,FILE='nephron/jmpct/jmpctparam.dat')
	OPEN (141,FILE='nephron/jmpct/jmpctresult.dat')
	OPEN (142,FILE='nephron/jmpct/jmpctbound.dat')
	OPEN (143,FILE='nephron/jmpct/jmpctptpick.dat')
	OPEN (144,FILE='nephron/jmpct/jmpctguess.dat')
	OPEN (145,FILE='nephron/jmpct/jmpctguess.new')
	OPEN (146,FILE='nephron/jmpct/jmpctptim.dat')
	OPEN (147,FILE='nephron/jmpct/jmpctfluxes.dat')
	OPEN (148,FILE='nephron/jmpct/jmpctxy.qo2')
	OPEN (149,FILE='nephron/jmpct/jmpctpres.dat')
C
	OPEN (130,FILE='nephron/jmpst/jmpstparam.dat')
	OPEN (131,FILE='nephron/jmpst/jmpstresult.dat')
	OPEN (132,FILE='nephron/jmpst/jmpstbound.dat')
	OPEN (133,FILE='nephron/jmpst/jmpstptpick.dat')
	OPEN (134,FILE='nephron/jmpst/jmpstguess.dat')
	OPEN (135,FILE='nephron/jmpst/jmpstguess.new')
	OPEN (136,FILE='nephron/jmpst/jmpstptim.dat')
	OPEN (137,FILE='nephron/jmpst/jmpstfluxes.dat')
	OPEN (138,FILE='nephron/jmpst/jmpstxy.qo2')
	OPEN (139,FILE='nephron/jmpst/jmpstpres.dat')
C
	OPEN (120,FILE='nephron/sdhl/sdhlparam.dat')
	OPEN (121,FILE='nephron/sdhl/sdhlresult.dat')
	OPEN (122,FILE='nephron/sdhl/sdhlbound.dat')
	OPEN (123,FILE='nephron/sdhl/sdhlptpick.dat')
	OPEN (124,FILE='nephron/sdhl/sdhlguess.dat')
	OPEN (125,FILE='nephron/sdhl/sdhlguess.new')
	OPEN (126,FILE='nephron/sdhl/sdhlptim.dat')
	OPEN (127,FILE='nephron/sdhl/sdhlfluxes.dat')
	OPEN (129,FILE='nephron/sdhl/sdhlpres.dat')
C
	OPEN (110,FILE='nephron/ldhlu/ldhluparam.dat')
	OPEN (111,FILE='nephron/ldhlu/ldhluresult.dat')
	OPEN (112,FILE='nephron/ldhlu/ldhlubound.dat')
	OPEN (113,FILE='nephron/ldhlu/ldhluptpick.dat')
	OPEN (114,FILE='nephron/ldhlu/ldhluguess.dat')
	OPEN (115,FILE='nephron/ldhlu/ldhluguess.new')
	OPEN (116,FILE='nephron/ldhlu/ldhluptim.dat')
	OPEN (117,FILE='nephron/ldhlu/ldhlufluxes.dat')
	OPEN (119,FILE='nephron/ldhlu/ldhlupres.dat')
C
	OPEN (100,FILE='nephron/ldhll/ldhllparam.dat')
	OPEN (101,FILE='nephron/ldhll/ldhllresult.dat')
	OPEN (102,FILE='nephron/ldhll/ldhllbound.dat')
	OPEN (103,FILE='nephron/ldhll/ldhllptpick.dat')
	OPEN (104,FILE='nephron/ldhll/ldhllguess.dat')
	OPEN (105,FILE='nephron/ldhll/ldhllguess.new')
	OPEN (106,FILE='nephron/ldhll/ldhllptim.dat')
	OPEN (107,FILE='nephron/ldhll/ldhllfluxes.dat')
	OPEN (109,FILE='nephron/ldhll/ldhllpres.dat')
C
	OPEN (90,FILE='nephron/tahl/tahlparam.dat')
	OPEN (91,FILE='nephron/tahl/tahlresult.dat')
	OPEN (92,FILE='nephron/tahl/tahlbound.dat')
	OPEN (93,FILE='nephron/tahl/tahlptpick.dat')
	OPEN (94,FILE='nephron/tahl/tahlguess.dat')
	OPEN (95,FILE='nephron/tahl/tahlguess.new')
	OPEN (96,FILE='nephron/tahl/tahlptim.dat')
	OPEN (97,FILE='nephron/tahl/tahlfluxes.dat')
	OPEN (99,FILE='nephron/tahl/tahlpres.dat')
C
	OPEN (80,FILE='nephron/ahlm/ahlmparam.dat')
	OPEN (81,FILE='nephron/ahlm/ahlmresult.dat')
	OPEN (82,FILE='nephron/ahlm/ahlmbound.dat')
	OPEN (83,FILE='nephron/ahlm/ahlmptpick.dat')
	OPEN (84,FILE='nephron/ahlm/ahlmguess.dat')
	OPEN (85,FILE='nephron/ahlm/ahlmguess.new')
	OPEN (86,FILE='nephron/ahlm/ahlmptim.dat')
	OPEN (87,FILE='nephron/ahlm/ahlmfluxes.dat')
	OPEN (89,FILE='nephron/ahlm/ahlmpres.dat')
C
	OPEN (70,FILE='nephron/ahlc/ahlcparam.dat')
	OPEN (71,FILE='nephron/ahlc/ahlcresult.dat')
	OPEN (72,FILE='nephron/ahlc/ahlcbound.dat')
	OPEN (73,FILE='nephron/ahlc/ahlcptpick.dat')
	OPEN (74,FILE='nephron/ahlc/ahlcguess.dat')
	OPEN (75,FILE='nephron/ahlc/ahlcguess.new')
	OPEN (76,FILE='nephron/ahlc/ahlcptim.dat')
	OPEN (77,FILE='nephron/ahlc/ahlcfluxes.dat')
	OPEN (79,FILE='nephron/ahlc/ahlcpres.dat')
C
	OPEN (60,FILE='nephron/dct/dcparam.dat')
	OPEN (61,FILE='nephron/dct/dcresult.dat')
	OPEN (62,FILE='nephron/dct/dcbound.dat')
	OPEN (63,FILE='nephron/dct/dcptpick.dat')
	OPEN (66,FILE='nephron/dct/dcptim.dat')
	OPEN (64,FILE='nephron/dct/dcguess.dat')
	OPEN (65,FILE='nephron/dct/dcguess.new')
	OPEN (67,FILE='nephron/dct/dcfluxes.dat')
	OPEN (69,FILE='nephron/dct/dctpres.dat')
C
	OPEN (50,FILE='nephron/cnt/cnparam.dat')
	OPEN (51,FILE='nephron/cnt/cnresult.dat')
	OPEN (52,FILE='nephron/cnt/cnbound.dat')
	OPEN (53,FILE='nephron/cnt/cnptpick.dat')
	OPEN (54,FILE='nephron/cnt/cnguess.dat')
	OPEN (55,FILE='nephron/cnt/cnguess.new')
	OPEN (56,FILE='nephron/cnt/cnptim.dat')
	OPEN (57,FILE='nephron/cnt/cnfluxes.dat')
	OPEN (59,FILE='nephron/cnt/cntpres.dat')
C
	OPEN (40,FILE='nephron/cct/ccparam.dat')
	OPEN (41,FILE='nephron/cct/ccresult.dat')
	OPEN (42,FILE='nephron/cct/ccbound.dat')
	OPEN (43,FILE='nephron/cct/ccptpick.dat')
	OPEN (44,FILE='nephron/cct/ccguess.dat')
	OPEN (45,FILE='nephron/cct/ccguess.new')
	OPEN (46,FILE='nephron/cct/ccptim.dat')
	OPEN (47,FILE='nephron/cct/ccfluxes.dat')
	OPEN (49,FILE='nephron/cct/cctpres.dat')
C
	OPEN (30,FILE='nephron/ompct/omparam.dat')
	OPEN (31,FILE='nephron/ompct/omresult.dat')
	OPEN (32,FILE='nephron/ompct/ombound.dat')
	OPEN (33,FILE='nephron/ompct/omptpick.dat')
	OPEN (34,FILE='nephron/ompct/omguess.dat')
	OPEN (35,FILE='nephron/ompct/omguess.new')
	OPEN (36,FILE='nephron/ompct/omptim.dat')
	OPEN (37,FILE='nephron/ompct/omfluxes.dat')
	OPEN (39,FILE='nephron/ompct/ompctpres.dat')
C
	OPEN (20,FILE='nephron/imct/imparam.dat')
	OPEN (21,FILE='nephron/imct/imresult.dat')
	OPEN (22,FILE='nephron/imct/imbound.dat')
	OPEN (23,FILE='nephron/imct/imptpick.dat')
	OPEN (24,FILE='nephron/imct/imguess.dat')
	OPEN (25,FILE='nephron/imct/imguess.new')
	OPEN (26,FILE='nephron/imct/imptim.dat')
	OPEN (27,FILE='nephron/imct/imfluxes.dat')
	OPEN (29,FILE='nephron/imct/imctpres.dat')
C
C
	OPEN (290,FILE='vasc/vrnum.dat')
	OPEN (291,FILE='vasc/vasc.dat')
	OPEN (292,FILE='vasc/xy.fv')
        OPEN (293,FILE='vasc/medjcs.dat')
        OPEN (294,FILE='vasc/medjcs.sum')
C
	OPEN (UNIT=201,FILE='vasc/omdvr/omdparam.dat')
	OPEN (UNIT=202,FILE='vasc/omdvr/omdbound.dat')
	OPEN (UNIT=203,FILE='vasc/omdvr/omdresult.dat')
	OPEN (UNIT=204,FILE='vasc/omdvr/omdend.dat')
C
	OPEN (UNIT=211,FILE='vasc/omavr/omaparam.dat')
	OPEN (UNIT=212,FILE='vasc/omavr/omabound.dat')
	OPEN (UNIT=213,FILE='vasc/omavr/omaresult.dat')
	OPEN (UNIT=214,FILE='vasc/omavr/omaend.dat')
C
	OPEN (UNIT=221,FILE='vasc/imdvr/imdparam.dat')
	OPEN (UNIT=222,FILE='vasc/imdvr/imdbound.dat')
	OPEN (UNIT=223,FILE='vasc/imdvr/imdresult.dat')
	OPEN (UNIT=224,FILE='vasc/imdvr/imdend.dat')
C
	OPEN (UNIT=231,FILE='vasc/imavr/imaparam.dat')
	OPEN (UNIT=232,FILE='vasc/imavr/imabound.dat')
	OPEN (UNIT=233,FILE='vasc/imavr/imaresult.dat')
	OPEN (UNIT=234,FILE='vasc/imavr/imaend.dat')
C
	OPEN (UNIT=241,FILE='vasc/mrdvr/mrdparam.dat')
	OPEN (UNIT=242,FILE='vasc/mrdvr/mrdbound.dat')
	OPEN (UNIT=243,FILE='vasc/mrdvr/mrdresult.dat')
	OPEN (UNIT=244,FILE='vasc/mrdvr/mrdend.dat')
C
	OPEN (UNIT=251,FILE='vasc/mravr/mraparam.dat')
	OPEN (UNIT=252,FILE='vasc/mravr/mrabound.dat')
	OPEN (UNIT=253,FILE='vasc/mravr/mraresult.dat')
	OPEN (UNIT=254,FILE='vasc/mravr/mraend.dat')
C
	OPEN (UNIT=261,FILE='vasc/oidvr/oidparam.dat')
	OPEN (UNIT=262,FILE='vasc/oidvr/oidbound.dat')
	OPEN (UNIT=263,FILE='vasc/oidvr/oidresult.dat')
	OPEN (UNIT=264,FILE='vasc/oidvr/oidend.dat')
C
	OPEN (UNIT=271,FILE='vasc/oiavr/oiaparam.dat')
	OPEN (UNIT=272,FILE='vasc/oiavr/oiabound.dat')
	OPEN (UNIT=273,FILE='vasc/oiavr/oiaresult.dat')
	OPEN (UNIT=274,FILE='vasc/oiavr/oiaend.dat')
C
	OPEN (UNIT=281,FILE='vasc/cor/corparam.dat')
	OPEN (UNIT=282,FILE='vasc/cor/corbound.dat')
	OPEN (UNIT=283,FILE='vasc/cor/corresult.dat')
	OPEN (UNIT=284,FILE='vasc/cor/corend.dat')
C
	OPEN (462,FILE='nephron/sfpct/sfpctbound.new')
	OPEN (452,FILE='nephron/sfpst/sfpstbound.new')
	OPEN (442,FILE='nephron/jmpct/jmpctbound.new')
	OPEN (432,FILE='nephron/jmpst/jmpstbound.new')
	OPEN (422,FILE='nephron/sdhl/sdhlbound.new')
	OPEN (412,FILE='nephron/ldhlu/ldhlubound.new')
	OPEN (402,FILE='nephron/ldhll/ldhllbound.new')
	OPEN (392,FILE='nephron/tahl/tahlbound.new')
	OPEN (382,FILE='nephron/ahlm/ahlmbound.new')
	OPEN (372,FILE='nephron/ahlc/ahlcbound.new')
	OPEN (782,FILE='nephron/sfahlm/sfahlmbound.new')
	OPEN (772,FILE='nephron/sfahlc/sfahlcbound.new')
	OPEN (762,FILE='nephron/sfdct/sfdcbound.new')
	OPEN (882,FILE='nephron/jmahlm/jmahlmbound.new')
	OPEN (872,FILE='nephron/jmahlc/jmahlcbound.new')
	OPEN (862,FILE='nephron/jmdct/jmdcbound.new')
	OPEN (362,FILE='nephron/dct/dcbound.new')
	OPEN (352,FILE='nephron/cnt/cnbound.new')
	OPEN (342,FILE='nephron/cct/ccbound.new')
	OPEN (332,FILE='nephron/ompct/ombound.new')
	OPEN (322,FILE='nephron/imct/imbound.new')
	OPEN (312,FILE='nephron/pstmr/pstmrbound.new')
C
	OPEN (580,FILE='nephron/sfahlm/sfahlmparam.dat')
	OPEN (581,FILE='nephron/sfahlm/sfahlmresult.dat')
	OPEN (582,FILE='nephron/sfahlm/sfahlmbound.dat')
	OPEN (583,FILE='nephron/sfahlm/sfahlmptpick.dat')
	OPEN (584,FILE='nephron/sfahlm/sfahlmguess.dat')
	OPEN (585,FILE='nephron/sfahlm/sfahlmguess.new')
	OPEN (586,FILE='nephron/sfahlm/sfahlmptim.dat')
	OPEN (587,FILE='nephron/sfahlm/sfahlmfluxes.dat')
	OPEN (589,FILE='nephron/sfahlm/sfahlmpres.dat')
C
	OPEN (570,FILE='nephron/sfahlc/sfahlcparam.dat')
	OPEN (571,FILE='nephron/sfahlc/sfahlcresult.dat')
	OPEN (572,FILE='nephron/sfahlc/sfahlcbound.dat')
	OPEN (573,FILE='nephron/sfahlc/sfahlcptpick.dat')
	OPEN (574,FILE='nephron/sfahlc/sfahlcguess.dat')
	OPEN (575,FILE='nephron/sfahlc/sfahlcguess.new')
	OPEN (576,FILE='nephron/sfahlc/sfahlcptim.dat')
	OPEN (577,FILE='nephron/sfahlc/sfahlcfluxes.dat')
	OPEN (579,FILE='nephron/sfahlc/sfahlcpres.dat')
C
	OPEN (560,FILE='nephron/sfdct/sfdcparam.dat')
	OPEN (561,FILE='nephron/sfdct/sfdcresult.dat')
	OPEN (562,FILE='nephron/sfdct/sfdcbound.dat')
	OPEN (563,FILE='nephron/sfdct/sfdcptpick.dat')
	OPEN (566,FILE='nephron/sfdct/sfdcptim.dat')
	OPEN (564,FILE='nephron/sfdct/sfdcguess.dat')
	OPEN (565,FILE='nephron/sfdct/sfdcguess.new')
	OPEN (567,FILE='nephron/sfdct/sfdcfluxes.dat')
	OPEN (569,FILE='nephron/sfdct/sfdctpres.dat')
C
	OPEN (680,FILE='nephron/jmahlm/jmahlmparam.dat')
	OPEN (681,FILE='nephron/jmahlm/jmahlmresult.dat')
	OPEN (682,FILE='nephron/jmahlm/jmahlmbound.dat')
	OPEN (683,FILE='nephron/jmahlm/jmahlmptpick.dat')
	OPEN (684,FILE='nephron/jmahlm/jmahlmguess.dat')
	OPEN (685,FILE='nephron/jmahlm/jmahlmguess.new')
	OPEN (686,FILE='nephron/jmahlm/jmahlmptim.dat')
	OPEN (687,FILE='nephron/jmahlm/jmahlmfluxes.dat')
	OPEN (689,FILE='nephron/jmahlm/jmahlmpres.dat')
C
	OPEN (670,FILE='nephron/jmahlc/jmahlcparam.dat')
	OPEN (671,FILE='nephron/jmahlc/jmahlcresult.dat')
	OPEN (672,FILE='nephron/jmahlc/jmahlcbound.dat')
	OPEN (673,FILE='nephron/jmahlc/jmahlcptpick.dat')
	OPEN (674,FILE='nephron/jmahlc/jmahlcguess.dat')
	OPEN (675,FILE='nephron/jmahlc/jmahlcguess.new')
	OPEN (676,FILE='nephron/jmahlc/jmahlcptim.dat')
	OPEN (677,FILE='nephron/jmahlc/jmahlcfluxes.dat')
	OPEN (679,FILE='nephron/jmahlc/jmahlcpres.dat')
C
	OPEN (660,FILE='nephron/jmdct/jmdcparam.dat')
	OPEN (661,FILE='nephron/jmdct/jmdcresult.dat')
	OPEN (662,FILE='nephron/jmdct/jmdcbound.dat')
	OPEN (663,FILE='nephron/jmdct/jmdcptpick.dat')
	OPEN (666,FILE='nephron/jmdct/jmdcptim.dat')
	OPEN (664,FILE='nephron/jmdct/jmdcguess.dat')
	OPEN (665,FILE='nephron/jmdct/jmdcguess.new')
	OPEN (667,FILE='nephron/jmdct/jmdcfluxes.dat')
	OPEN (669,FILE='nephron/jmdct/jmdctpres.dat')
C
	SOL(1)='  NA '
	SOL(2)='  K  '
	SOL(3)='  CL '
	SOL(4)=' HCO3'
	SOL(5)='H2CO3'
	SOL(6)=' CO2 '
	SOL(7)=' HPO4'
	SOL(8)='H2PO4'
	SOL(9)=' UREA'
	SOL(10)=' NH3 '
	SOL(11)=' NH4+'
	SOL(12)='  H+ '
	SOL(13)='HCO2-'
	SOL(14)='H2CO2'
	SOL(15)=' GLUC'
	SOL(16)=' PROT'
C
	T=1
	TIME=0.D0
C
C ASSIGN MODEL PARAMETERS, INCLUDING CORTICAL IS PRESSURE AND SOLUTE CONCENTRATIONS
C  CORTICAL CONDITIONS ARE READ AS PSMR(1,1) AND CSMR(I,1,1)
C    WHICH ARE ALSO EQUAL TO PSOM(1,1) AND CSOM(I,1,1)
C
        CALL KBSET(
     1   FVM0,AFVM,DFVM,AFVM0,DFVM0,MDCL,DMDCL,DNR,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0)
C
        SOLS=15
        NN=14+SLICE+(SLICE+1)*SOLS
	PTOL=1.D-18
	M1=1008
	IERR=0
        NIL='    --     '
        DO 2 ISOL=1,SOLS+1
        DO 2 ISLC=1,SLICE+1
    2   VMAT(ISOL,ISLC)=NIL
C
        CALL KGAMINIT(GAMMA,RGUESS,
     1   FVM0,AFVM,DFVM,AFVM0,DFVM0,MDCL,DMDCL,DNR,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0)
C
        DO 10 K=1,NN
C   10   DGAM(K)=0.1D-3*GAMMA(K)
   10   DGAM(K)=0.1D-3*GAMMA(K)
C
C KGAM PROVIDES TRANSLATION FROM SLICE GUESSES TO BOUNDARY DATA
C  FOR MEDULLARY AND MEDULLARY RAY STRUCTURES
C  PRESSURE AND FLOW CHANGES OF TGGAM WILL BE TRANSLATED WITHIN NEPHRON
C
        CALL KGAM(GAMMA,1,
     1   FVM0,AFVM,DFVM,AFVM0,DFVM0,MDCL,DMDCL,DNR,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0)
        CALL KIS(
     1   FVM0,AFVM,DFVM,AFVM0,DFVM0,MDCL,DMDCL,DNR,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0)
C
C THERE WAS ENOUGH INFORMATION TO DETERMINE ALL OF THE INTERSTITIAL CONDITIONS
C  THROUGHOUT THE WHOLE KIDNEY MODEL (TUBULES AND VESSELS).
C THIS WAS DONE IN KGAM, RATHER THAN IN INDIVIDUAL TUBULE AND VESSEL ROUTINES
C  --AVOIDS INCONSISTENCIES AMONG THE 20 SUBROUTINES
C BOUNDARY DATA WILL BE ESTABLISHED IN THE FLOW.F ROUTINE, RATHER THAN IN *NEWT.F
C
C VASCULAR PARAMETERS
C
        READ (290,25) (RADVR(I),RDNUM(I),I=1,9)
   25   FORMAT(2D12.4)
        DO 26 I=1,8
   26   RANUM(I)=RDNUM(I)*RADVR(I)
C
C EXPERIMENTS WILL CYCLE FROM THIS POINT.
C
C	PRINT 30
   30   FORMAT(' NUMBER OF EXPERIMENTS = ',$)
C	READ *, EXP
        EXP=1
C
C ALLOW FOR 'SUBPROBLEMS' IN WHICH A SUBSET OF THE NN GAMMA AND PHI ARE SELECTED
	CALL KREDUCE(SLICE,OMSLC,IMSLC,MRSLC,
     1   IN,IG,IP,NSLC,NCOR,KSLC,NTGF,NPR,NVOL,KVOL,NSOL,KSOL)
C  
        PRINT 33
   33   FORMAT(' ESCAL= ',$)
        READ *, ESCAL
C
C	DO 600 COUNT=1,EXP
        count=1
C
C TG FEEDBACK SETTINGS: (Set outside proximal tubule since they involve AHL)
        READ(13,35) TGEPSI,DNR,
     1   (AFVM0(J),DFVM0(J),MDCL(J),DMDCL(J),J=1,2)
   35   FORMAT(2D12.4,/,4D12.4,/,4D12.4)
C
        CALL NEPHRON(TGPHI,COUNT,0,RGUESS,
     1   FVM0,AFVM,DFVM,AFVM0,DFVM0,MDCL,DMDCL,DNR,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0)
        CALL GEN(1,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   OMDIST,IMDIST,MRDIST,OMJVMS,OMJKMS,IMJVMS,IMJKMS,
     1   MRJVMS,MRJKMS,MEDJVMS,MEDJKMS,SEGV,SEGK,OMJVCS,OMJKCS,
     1   IMJVCS,IMJKCS,MRJVCS,MRJKCS,MEDJVCS,MEDJKCS,VSEGV,VSEGK)
C
C CHECK THE VASCULAR FLUXES
C
        CALL VASC(COUNT,0,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0)
        CALL VGEN(1,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   OMDIST,IMDIST,MRDIST,OMJVMS,OMJKMS,IMJVMS,IMJKMS,
     1   MRJVMS,MRJKMS,MEDJVMS,MEDJKMS,SEGV,SEGK,OMJVCS,OMJKCS,
     1   IMJVCS,IMJKCS,MRJVCS,MRJKCS,MEDJVCS,MEDJKCS,VSEGV,VSEGK)
C
C CHECK THE ERROR VECTOR
C
        CALL KERR(TGPHI,PHI,
     1   FVM0,AFVM,DFVM,AFVM0,DFVM0,MDCL,DMDCL,DNR,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0,
     1   OMDIST,IMDIST,MRDIST,OMJVMS,OMJKMS,IMJVMS,IMJKMS,
     1   MRJVMS,MRJKMS,MEDJVMS,MEDJKMS,SEGV,SEGK,OMJVCS,OMJKCS,
     1   IMJVCS,IMJKCS,MRJVCS,MRJKCS,MEDJVCS,MEDJKCS,VSEGV,VSEGK)
C
        DO 39 ISOL=1,SOLS
   39   ALABL(ISOL)=SOL(ISOL)
        ALABL(4)=' TCO2'
        ALABL(5)=' PKC '
        ALABL(6)='CO2HY'
        ALABL(7)=' TPO4'
        ALABL(8)=' PKP '
        ALABL(10)=' TAMM'
        ALABL(11)=' PKN '
        ALABL(13)='TFORM'
        ALABL(14)=' PKF '
C
        ITER=1
        WRITE(304,40) ITER
   40   FORMAT(/,2X,'ITER=',I3)
        PRINT 40, ITER
C
        IF((NTGF.EQ.0).AND.(NPR.EQ.0)) THEN
        PRINT 102, (NIL,ITGF=1,NTGF+NPR)
        WRITE(304,102) (NIL,ITGF=1,NTGF+NPR)
  102   FORMAT(7X,4X,13A11)
        ELSE IF((NTGF.EQ.0).AND.(NPR.NE.0)) THEN
        PRINT 104, (NIL,TGGAM(IG(ITGF)),ITGF=1,NPR-1),TGGAM(IG(NPR))
        WRITE(304,104) (NIL,TGGAM(IG(ITGF)),ITGF=1,NPR-1),TGGAM(IG(NPR))
  104   FORMAT(7X,4X,6(A5,6X,D11.3),D11.3)
        ELSE IF((NTGF.NE.0).AND.(NPR.EQ.0)) THEN
        PRINT 106, (TGGAM(IG(ITGF)),NIL,ITGF=1,NTGF)
        WRITE(304,106) (TGGAM(IG(ITGF)),NIL,ITGF=1,NTGF)
  106   FORMAT(7X,4X,6(D11.3,A11))
        ELSE
        PRINT 108, (TGGAM(ITGF),ITGF=1,NTGF+NPR)
        WRITE(304,108) (TGGAM(ITGF),ITGF=1,NTGF+NPR)
  108   FORMAT(7X,4X,13D11.3)
        ENDIF
C
C FIRST PRINT ALL OF THE IG(XX) VARIABLES INTO THE VMAT MATRIX
C   VOLUME ALONG THE FIRST ROW, THEN SOLUTES IN ROWS 2-16
C
        IF((NSLC+NCOR).EQ.0) GO TO 150
        IF(NVOL.EQ.0) GO TO 120
        DO 114 IVOL=1,NVOL
  114   WRITE(VMAT(1,KVOL(IVOL)),105) GAMMA(13+KVOL(IVOL))
  105   FORMAT(D11.3)
C
  120   IF(NSOL.EQ.0) GO TO 150
        DO 130 ISLC=1,NSLC+NCOR
        DO 125 ISOL=1,NSOL
  125   WRITE(VMAT(1+KSOL(ISOL),KSLC(ISLC)),105) 
     1    GAMMA(IG(NTGF+NPR+NVOL+(ISLC-1)*NSOL+ISOL))
  130   CONTINUE
C
C SOLUTES ARE ALONG THE ROWS, AND X-VALUES ARE DOWN THE COLUMNS (VMAT-TRANSPOSE)
C
  150   CONTINUE
        PRINT 152, (SOL(ISOL), ISOL=1,SOLS)
        WRITE(304,152) (SOL(ISOL), ISOL=1,SOLS)
  152   FORMAT(2X,'SLICE',4X,4X,'VOL',3X,15A11)
        DO 154 ISLC=1,SLICE+1
        PRINT 156, ISLC,VMAT(1,ISLC),(VMAT(1+ISOL,ISLC),ISOL=1,SOLS)
        WRITE(304,156) ISLC,VMAT(1,ISLC),(VMAT(1+ISOL,ISLC),ISOL=1,SOLS)
  154   CONTINUE
  156   FORMAT(2X,I3,6X,16A11)
C
        PRINT 161, (TGPHI(K),K=1,13)
        WRITE(304,161) (TGPHI(K),K=1,13)
  161   FORMAT(/,7X,4X,13D11.3)
        PRINT 152, (ALABL(ISOL), ISOL=1,SOLS)
        WRITE(304,152) (ALABL(ISOL), ISOL=1,SOLS)
        DO 164 ISLC=1,SLICE+1
        PRINT 166, ISLC, PHI(13+ISLC),
     1   (PHI(14+SLICE+(ISLC-1)*(SOLS)+ISOL),ISOL=1,SOLS)
        WRITE(304,166) ISLC, PHI(13+ISLC),
     1   (PHI(14+SLICE+(ISLC-1)*(SOLS)+ISOL),ISOL=1,SOLS)
  164   CONTINUE
  166   FORMAT(2X,I3,6X,16D11.3)
C
C	
	MAXPHI=DABS(PHI(IP(1)))
	MAXJ=IP(1)
	DO 110 J=1,IN
	IF (MAXPHI.LT.DABS(PHI(IP(J)))) MAXJ=IP(J)
  110   IF (MAXPHI.LT.DABS(PHI(IP(J)))) MAXPHI=DABS(PHI(IP(J)))
        WRITE(304,112) MAXJ, MAXPHI
	PRINT 112, MAXJ, MAXPHI
  112   FORMAT (1X,I5,D12.4)
	IF(MAXPHI.LT.KEPSI) GO TO 401
C
C THE PHI ARE TOO LARGE.
C   WE WILL DETERMINE THE DERIVATIVE OF THE PHI WITH RESPECT TO
C THE VARIABLES ,GAMMA, AND STORE THESE IN THE ARRAY NDERIV( , ).
C
C
  199   CONTINUE
C
!$OMP PARALLEL DO SHARED(NN,IN,IG,DGAM,PHI,NDERIV,RGUESS,COUNT) 
!$OMP& FIRSTPRIVATE(GAMMA,PPHI,SOLS,X,T,TGPHI,
!$OMP& FVM0,AFVM,DFVM,AFVM0,DFVM0,MDCL,DMDCL,DNR,
!$OMP& RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
!$OMP& RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
!$OMP& RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
!$OMP& RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
!$OMP& RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
!$OMP& RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
!$OMP& RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
!$OMP& RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
!$OMP& RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
!$OMP& RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
!$OMP& RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
!$OMP& RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
!$OMP& RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
!$OMP& RMVL,RMVD,RRMT0,
!$OMP& RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
!$OMP& RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
!$OMP& RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
!$OMP& RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
!$OMP& RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
!$OMP& RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
!$OMP& OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
!$OMP& CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
!$OMP& TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
!$OMP& PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0,
!$OMP& OMDIST,IMDIST,MRDIST,OMJVMS,OMJKMS,IMJVMS,IMJKMS,
!$OMP& MRJVMS,MRJKMS,MEDJVMS,MEDJKMS,SEGV,SEGK,OMJVCS,OMJKCS,
!$OMP& IMJVCS,IMJKCS,MRJVCS,MRJKCS,MEDJVCS,MEDJKCS,VSEGV,VSEGK)
C
	DO  200 K=1,IN
	GAMMA(IG(K))=GAMMA(IG(K))+DGAM(IG(K))
        CALL KGAM(GAMMA,1,
     1   FVM0,AFVM,DFVM,AFVM0,DFVM0,MDCL,DMDCL,DNR,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0)
        CALL KIS(
     1   FVM0,AFVM,DFVM,AFVM0,DFVM0,MDCL,DMDCL,DNR,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0)
C
	CALL NEPHRON(TGPHI,COUNT,2,RGUESS,
     1   FVM0,AFVM,DFVM,AFVM0,DFVM0,MDCL,DMDCL,DNR,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0)
        CALL GEN(0,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   OMDIST,IMDIST,MRDIST,OMJVMS,OMJKMS,IMJVMS,IMJKMS,
     1   MRJVMS,MRJKMS,MEDJVMS,MEDJKMS,SEGV,SEGK,OMJVCS,OMJKCS,
     1   IMJVCS,IMJKCS,MRJVCS,MRJKCS,MEDJVCS,MEDJKCS,VSEGV,VSEGK)
C
        CALL VASC(COUNT,2,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0)
        CALL VGEN(0,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   OMDIST,IMDIST,MRDIST,OMJVMS,OMJKMS,IMJVMS,IMJKMS,
     1   MRJVMS,MRJKMS,MEDJVMS,MEDJKMS,SEGV,SEGK,OMJVCS,OMJKCS,
     1   IMJVCS,IMJKCS,MRJVCS,MRJKCS,MEDJVCS,MEDJKCS,VSEGV,VSEGK)
C
        CALL KERR(TGPHI,PPHI,
     1   FVM0,AFVM,DFVM,AFVM0,DFVM0,MDCL,DMDCL,DNR,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0,
     1   OMDIST,IMDIST,MRDIST,OMJVMS,OMJKMS,IMJVMS,IMJKMS,
     1   MRJVMS,MRJKMS,MEDJVMS,MEDJKMS,SEGV,SEGK,OMJVCS,OMJKCS,
     1   IMJVCS,IMJKCS,MRJVCS,MRJKCS,MEDJVCS,MEDJKCS,VSEGV,VSEGK)
C
	DO 210 J=1,NN
  210   NDERIV(J,IG(K))=(PPHI(J)-PHI(J))/DGAM(IG(K))
C
	GAMMA(IG(K))=GAMMA(IG(K))-DGAM(IG(K))
        CALL KGAM(GAMMA,1,
     1   FVM0,AFVM,DFVM,AFVM0,DFVM0,MDCL,DMDCL,DNR,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0)
        CALL KIS(
     1   FVM0,AFVM,DFVM,AFVM0,DFVM0,MDCL,DMDCL,DNR,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0)
        PRINT 201
  201   FORMAT('.',$)
  200   CONTINUE
C
!$OMP END PARALLEL DO
C
C THE JACOBIAN HAS BEEN COMPUTED NUMERICALLY. THE CURRENT GUESSES
C SIT IN GAMMA AND THE ERRORS IN PHI.  IT REMAINS TO COMPUTE
C NDERIV-1(PHI) AT THE CORRECTION TO BE SUBTRACTED FROM GAMMA.
C  FIRST FORMULATE THE REDUCED PROBLEM
C
  219   DO 220 K=1,IN
  220   RGAMMA(K)=GAMMA(IG(K))
        DO 222 J=1,IN
  222   RPHI(J)=PHI(IP(J))
C
        DO 225 K=1,IN
        DO 225 J=1,IN
  225   RDERIV(J,K)=NDERIV(IP(J),IG(K))
C
        DO 227 J=1,IN
  227   WRITE(305,228) (RDERIV(J,K),K=1,IN)
  228   FORMAT(6D20.12)
C
	CALL LES8(RDERIV,RPHI,PR,PFL,IN,SW,PTOL,DELGAM,M1)
	IF (SW) 230,600,230
C
  230   CONTINUE
        DSCAL=1.D0-ESCAL**(ITER**2)
        PRINT 231, DSCAL
        WRITE(304,231) DSCAL
  231   FORMAT (8X,'DSCAL=',D12.4)
        DO 232 K=1,IN
  232   RGAMMA(K)=RGAMMA(K)-DSCAL*DELGAM(K)
C  232   RGAMMA(K)=RGAMMA(K)-DELGAM(K)
        ITER=ITER+1
C
C        PRINT 49, (DELGAM(K),K=1,IN)
C        PRINT 49, (RGAMMA(K),K=1,IN)

        DO 235 K=1,IN
  235   GAMMA(IG(K))=RGAMMA(K)
        CALL KGAM(GAMMA,1,
     1   FVM0,AFVM,DFVM,AFVM0,DFVM0,MDCL,DMDCL,DNR,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0)
        CALL KIS(
     1   FVM0,AFVM,DFVM,AFVM0,DFVM0,MDCL,DMDCL,DNR,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0)
C
C RETEST THIS CORRECTION
C
        count=2
	CALL NEPHRON(TGPHI,COUNT,2,RGUESS,
     1   FVM0,AFVM,DFVM,AFVM0,DFVM0,MDCL,DMDCL,DNR,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0)
        CALL GEN(1,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   OMDIST,IMDIST,MRDIST,OMJVMS,OMJKMS,IMJVMS,IMJKMS,
     1   MRJVMS,MRJKMS,MEDJVMS,MEDJKMS,SEGV,SEGK,OMJVCS,OMJKCS,
     1   IMJVCS,IMJKCS,MRJVCS,MRJKCS,MEDJVCS,MEDJKCS,VSEGV,VSEGK)
C
        CALL VASC(COUNT,2,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0)
        CALL VGEN(1,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   OMDIST,IMDIST,MRDIST,OMJVMS,OMJKMS,IMJVMS,IMJKMS,
     1   MRJVMS,MRJKMS,MEDJVMS,MEDJKMS,SEGV,SEGK,OMJVCS,OMJKCS,
     1   IMJVCS,IMJKCS,MRJVCS,MRJKCS,MEDJVCS,MEDJKCS,VSEGV,VSEGK)
C
        CALL KERR(TGPHI,PHI,
     1   FVM0,AFVM,DFVM,AFVM0,DFVM0,MDCL,DMDCL,DNR,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0,
     1   OMDIST,IMDIST,MRDIST,OMJVMS,OMJKMS,IMJVMS,IMJKMS,
     1   MRJVMS,MRJKMS,MEDJVMS,MEDJKMS,SEGV,SEGK,OMJVCS,OMJKCS,
     1   IMJVCS,IMJKCS,MRJVCS,MRJKCS,MEDJVCS,MEDJKCS,VSEGV,VSEGK)
C
        WRITE(304,40) ITER
        PRINT 40, ITER
C
        IF((NTGF.EQ.0).AND.(NPR.EQ.0)) THEN
        PRINT 102, (NIL,ITGF=1,NTGF+NPR)
        WRITE(304,102) (NIL,ITGF=1,NTGF+NPR)
        ELSE IF((NTGF.EQ.0).AND.(NPR.NE.0)) THEN
        PRINT 104, (NIL,TGGAM(IG(ITGF)),ITGF=1,NPR-1),TGGAM(IG(NPR))
        WRITE(304,104) (NIL,TGGAM(IG(ITGF)),ITGF=1,NPR-1),TGGAM(IG(NPR))
        ELSE IF((NTGF.NE.0).AND.(NPR.EQ.0)) THEN
        PRINT 106, (TGGAM(IG(ITGF)),NIL,ITGF=1,NTGF)
        WRITE(304,106) (TGGAM(IG(ITGF)),NIL,ITGF=1,NTGF)
        ELSE
        PRINT 108, (TGGAM(ITGF),ITGF=1,NTGF+NPR)
        WRITE(304,108) (TGGAM(ITGF),ITGF=1,NTGF+NPR)
        ENDIF
C
C FIRST PRINT ALL OF THE IG(XX) VARIABLES INTO THE VMAT MATRIX
C   VOLUME ALONG THE FIRST ROW, THEN SOLUTES IN ROWS 2-16
C
        IF((NSLC+NCOR).EQ.0) GO TO 350
        IF(NVOL.EQ.0) GO TO 320
        DO 314 IVOL=1,NVOL
  314   WRITE(VMAT(1,KVOL(IVOL)),105) GAMMA(13+KVOL(IVOL))
C
  320   IF(NSOL.EQ.0) GO TO 350
        DO 330 ISLC=1,NSLC+NCOR
        DO 325 ISOL=1,NSOL
  325   WRITE(VMAT(1+KSOL(ISOL),KSLC(ISLC)),105) 
     1    GAMMA(IG(NTGF+NPR+NVOL+(ISLC-1)*NSOL+ISOL))
  330   CONTINUE
C
  350   CONTINUE
        PRINT 152, (SOL(ISOL), ISOL=1,SOLS)
        WRITE(304,152) (SOL(ISOL), ISOL=1,SOLS)
        DO 354 ISLC=1,SLICE+1
        PRINT 156, ISLC,VMAT(1,ISLC),(VMAT(1+ISOL,ISLC),ISOL=1,SOLS)
        WRITE(304,156) ISLC,VMAT(1,ISLC),(VMAT(1+ISOL,ISLC),ISOL=1,SOLS)
  354   CONTINUE
C
        PRINT 161, (TGPHI(K),K=1,13)
        WRITE(304,161) (TGPHI(K),K=1,13)
        PRINT 152, (ALABL(ISOL), ISOL=1,SOLS)
        WRITE(304,152) (ALABL(ISOL), ISOL=1,SOLS)
        DO 364 ISLC=1,SLICE+1
        PRINT 166, ISLC, PHI(13+ISLC),
     1   (PHI(14+SLICE+(ISLC-1)*(SOLS)+ISOL),ISOL=1,SOLS)
        WRITE(304,166) ISLC, PHI(13+ISLC),
     1   (PHI(14+SLICE+(ISLC-1)*(SOLS)+ISOL),ISOL=1,SOLS)
  364   CONTINUE
C
        PREMAX=MAXPHI
	MAXPHI=DABS(PHI(IP(1)))
	MAXJ=IP(1)
	DO 250 J=1,IN
	IF (MAXPHI.LT.DABS(PHI(IP(J)))) MAXJ=IP(J)
  250   IF (MAXPHI.LT.DABS(PHI(IP(J)))) MAXPHI=DABS(PHI(IP(J)))
        WRITE(304,112) MAXJ, MAXPHI
	PRINT 112, MAXJ, MAXPHI
	IF(MAXPHI.LT.KEPSI) GO TO 401
C
	IF (ITER.LT.20) THEN
        IF (MAXPHI.LE.0.1D0*PREMAX) GO TO 219
        IF (MAXPHI.GT.0.1D0*PREMAX) GO TO 199
        ELSE
        ENDIF
C
C IF THE SPATIAL ITERATION FAILS TO CONVERGE THE PROGRAM STOPS.
	PRINT 280
  280   FORMAT (' TOO MANY ITERATIONS IN KIDNEY')
	STOP
C
C THE SPATIAL STEP CONVERGED,AND THE PROGRAM PICKS UP AT THIS POINT:
C
  401   CONTINUE
        CALL RESULT(COUNT,
     1   FVM0,AFVM,DFVM,AFVM0,DFVM0,MDCL,DMDCL,DNR,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0)
        CALL VRESULT(COUNT,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0)
C
  419   WRITE (15,420) (TGGAM(J),J=1,13)
  420   FORMAT(D30.20)
        WRiTE (303,428) (FVCGAM(K),K=1,MRSLC+1),
     1    (PSGAM(K),K=MRSLC+2,SLICE+2)
        DO 472 J=1,11
  472   WRITE (303,428) (CSGAM(J,K),K=1,SLICE+2)
        DO 474 J=13,15
  474   WRITE (303,428) (CSGAM(J,K),K=1,SLICE+2)
  428   FORMAT(5D30.20)
C  428   FORMAT(10D16.8)
C
	CALL KAMMSUM(TGPHI,PHI,
     1   FVM0,AFVM,DFVM,AFVM0,DFVM0,MDCL,DMDCL,DNR,
     1   RX,RCHOP,RDIST,REPSI,RL0,RL,RKHY,RKDHY,RBCO2,
     1   RVM,RPM,RCM,RIMPM,RLCHM,RXM,RVS,RPS,RCS,RIMPS,RLCHS,RXS,
     1   RTL,RDX,RRM0,RMUM,RETA,RSM,RAM,RFVM,RFKM,RAME,RAE0,RAE,
     1   RMUA,RCHVL0,RCHVL,RMUV,RLPME,RLPES,RSME,RSES,RHME,RHES,
     1   RVE,RPE,RCE,RLCHE,RXE,RFEVM,RFEKM,RFEVS,RFEKS,RCURE,
     1   RAIE,RAMI,RAIS,RAI0,RCLVL0,RIMP0,RCLVL,RZIMP,
     1   RTBUF,RPKB,RCBUF,RHCBUF,RLPMI,RLPIS,RSMI,RSIS,RHMI,RHIS,
     1   RLMI,RLIS,RATMI,RATIS,RATIE,RVI,RPI,RCI,RIMP,RLCHI,RXI,
     1   RFIVM,RFIKM,RFIVS,RFIKS,RCURI,RJV,RJK,RISOFM,RNP,RKNPN,RKNPK,
     1   RKNH4,RNPHK,RLHP,RXIHP,RXHP,RNAE1,RNTSC,RNNHE3,RJNAK,RJHK,
     1   RJHP,RJAE1,RJTSC,RJNHE3,RQIAMM,RNNKCC,RNKCL,RJNKCC,RJKCC,
     1   RTQM,RRM,RMUR,RSCALMI,RSCALIS,RVM0,RAM0,RTQM0,RLHP0,RNP0,
     1   RNNHE30,RLPMI0,RLPIS0,RHMI0,RHIS0,RLMI0,RLIS0,RQIAMM0,
     1   RMVL,RMVD,RRMT0,
     1   RVX,RVCHOP,RADVR,RDNUM,RANUM,RVEPSI,RVDIST,RVKHY,RVKDHY,
     1   RVDX,RVETA,RCL,RRC0,RMUC,RLPCS,RSCS,RLCS,RHCS,
     1   RLPCSE,RSCSE,RLCSE,RHCSE,RLPCSI,RSCSI,RLCSI,RHCSI,
     1   RVVS,RVPS,RVCS,RVIMPS,RVLCHS,RVXS,RVC,RPC,RCC,RIMPC,RLCHC,RXC,
     1   RSAT,RCCN,RCCX,RCCY,RSC,RAC,RFVC,RFKC,RFVCS,RFKCS,
     1   RFVCSE,RFKCSE,RFVCSI,RFKCSI,RHCTC,RFBC,RPOX,
     1   OMCHOP,IMCHOP,MRCHOP,OMSLC,IMSLC,MRSLC,SLICE,
     1   CSMR,CSOM,CSIM,PSMR,PSOM,PSIM,
     1   TGEPSI,TGGAM,CSGAM,PSGAM,KEPSI,FVCGAM,FVCMR,
     1   PS0,IMPM0,IMPS0,CM0,CS0,FVC0,PC0,IMPC0,HCT0,CC0,
     1   OMDIST,IMDIST,MRDIST,OMJVMS,OMJKMS,IMJVMS,IMJKMS,
     1   MRJVMS,MRJKMS,MEDJVMS,MEDJKMS,SEGV,SEGK,OMJVCS,OMJKCS,
     1   IMJVCS,IMJKCS,MRJVCS,MRJKCS,MEDJVCS,MEDJKCS,VSEGV,VSEGK)
C
  600   CONTINUE
	STOP
	END
