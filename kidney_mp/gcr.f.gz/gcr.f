        PROGRAM GCR
C
C  Program to read the interstitial variables, compute the proton concentrations,
C   and check that all of the buffer pairs yield consistent pH.
C  These variables are output to a file with expanded/compressed interstitial guesses
C
C LOCAL VARIABLES
C
	INTEGER SOLS,
     1    SLICE(2),OMSLC(2),IMSLC(2),MRSLC(2),
     1    OMSCAL,IMSCAL,MRSCAL
C
C       SLICE-  OM+IM+MR DISCRETIZATION OF GUESSES 
C               (REFINED TO OMCHOP+IMCHOP+MRCHOP BY LINEAR INTERPOLATION)
C               GAMMA VECTOR IS BASED ON SLICE
C
	INTEGER ISEG,NN(15),NSOLS(15)
C
C GENERAL PARAMETERS
	DOUBLE PRECISION
     1   Z(15),PKC,PKF,PKN,PKP,
     1   LCHS(91),TPS,TNS,TFS,QPS,QNS,QFS
C
C SPECIFIED BOUNDARY DATA
C
        DOUBLE PRECISION CSGAM(15,91,2),PSGAM(91,2)
C
C       CSGAM-  GUESS CS CONCENTRATIONS AT SLICE BOUNDARIES
C       PSGAM-  GUESS PS VALUES AT SLICE BOUNDARIES
C
C	
C FOR THE BASELINE CONFIRGURATION:
C  SLICE DEMARCATIONS AT 0 - 7 MM FROM OM TO PAPILLA
C  THE INITIAL POINT AT 0 MM CORRESPONDS TO A SINGLE MR SLICE, 2MM IN THICKNESS
C Interstitial unknows are pressure and concentration at 2 points in OM, 5 points
C  in IM, and one point in MR.  The x=0 point in OM abuts PST; there is a second
c  x=0 point in OM that is identified with MR=2mm, and this abuts AHL and OMCD.
C The points MR(1) and OM(1) will be assigned cortical concentrations, so there
C  are a total of 8 sets of IS unknowns.
C
C                                       MR(1)
C
C                                       MR(2)
C                _____________________________________ (continuity MR->OM)
C                        OM(1)          MR(2)
C                             \        /
C                             OM(2)=MR(3)
C                             OM(3)=MR(4)
C                _____________________________________ (continuity OM->IM)
C                                OM(3)
C                                IM(1)
C                                 ...
C                                IM(5)
C
C (9/16/18) With the introduction of finer chop, we will still continue to insist on a 
C  well-stirred OM, without distinguishing special MR comparment within OM.  The rationale
C  is that the Layton observations is that such differences are small.
C
C  SOLUTE INDEX:
C	1-	NA+
C	2-	K+
C	3-	CL-
C	4-	HCO3-
C	5-	H2CO3
C	6-	CO2
C	7-	HPO4--
C	8-	H2PO4-
C	9-	UREA
C	10-	NH3
C	11-	NH4+
C	12-	H+
C	13-	HCO2-
C	14-	H2CO2
C	15-	GLUC
C
        OPEN (301,FILE='kguess.tem')
        OPEN (303,FILE='kguess.out')
C
	Z(1)=1.D0
	Z(2)=1.D0
	Z(3)=-1.D0
	Z(4)=-1.D0
	Z(5)=0.D0
	Z(6)=0.D0
	Z(7)=-2.D0
	Z(8)=-1.D0
	Z(9)=0.D0
	Z(10)=0.D0
	Z(11)=1.D0
	Z(12)=1.D0
	Z(13)=-1.D0
	Z(14)=0.D0
	Z(15)=0.D0
C
	PKC=3.57
	PKF=3.76
	PKP=6.8
	PKN=9.15
        SOLS=15
C
C READ THE GUESSES AT THE SLICE LEVELS: MR(1-2), OM(1-3), IM(1-5)
C   RECALL THAT MR(1) AND OM(1) ARE BOTH EQUAL TO CORTICAL VALUES
C The pressures and solute are read in, first MR and then OM -> IM.
C
	READ (301,30) OMSLC(1),IMSLC(1),MRSLC(1)
   30   FORMAT (3I5)
	SLICE(1) = OMSLC(1)+IMSLC(1)+MRSLC(1)
C
        READ (301,28) (PSGAM(K,1),K=1,SLICE(1)+2)
        DO 22 J=1,11
   22   READ (301,28) (CSGAM(J,K,1),K=1,SLICE(1)+2)
        DO 24 J=13,15
   24   READ (301,28) (CSGAM(J,K,1),K=1,SLICE(1)+2)
   28   FORMAT(5D30.20)
C
        DO 34 K=1,SLICE(1)+2
	LCHS(K)=PKC + DLOG10(CSGAM(4,K,1)/CSGAM(5,K,1))
	CSGAM(12,K,1)=10.**(-LCHS(K))
C
	TPS=CSGAM(7,K,1)+CSGAM(8,K,1)
	TNS=CSGAM(10,K,1)+CSGAM(11,K,1)
	TFS=CSGAM(13,K,1)+CSGAM(14,K,1)
C
	QPS=10.**(LCHS(K)-PKP)
	QNS=10.**(LCHS(K)-PKN)
	QFS=10.**(LCHS(K)-PKF)
C
	CSGAM(8,K,1)=TPS/(1.+QPS)
	CSGAM(7,K,1)=TPS-CSGAM(8,K,1)
	CSGAM(11,K,1)=TNS/(1.+QNS)
	CSGAM(10,K,1)=TNS-CSGAM(11,K,1)
	CSGAM(14,K,1)=TFS/(1.+QFS)
	CSGAM(13,K,1)=TFS-CSGAM(14,K,1)
C
	CSGAM(3,K,1)= CSGAM(1,K,1)*Z(1) + CSGAM(2,K,1)*Z(2)
	DO 33 I=4,SOLS
   33   CSGAM(3,K,1)=CSGAM(3,K,1)+CSGAM(I,K,1)*Z(I)
   34   CONTINUE
C
        PRINT 42, MRSLC(1)
   42   FORMAT('OLD MRSLC=',I2,5X,'NEW MRSLC=',$)
        READ *, MRSLC(2)
        MRSCAL=MRSLC(2)/MRSLC(1)
        PRINT 44, OMSLC(1)
   44   FORMAT('OLD OMSLC=',I2,5X,'NEW OMSLC=',$)
        READ *, OMSLC(2)
        OMSCAL=OMSLC(2)/OMSLC(1)
        PRINT 46, IMSLC(1)
   46   FORMAT('OLD IMSLC=',I2,5X,'NEW IMSLC=',$)
        READ *, IMSLC(2)
        IMSCAL=IMSLC(2)/IMSLC(1)
	SLICE(2) = OMSLC(2)+IMSLC(2)+MRSLC(2)
C
        DO 58 K=1,MRSLC(1)
        DO 56 J=1,MRSCAL+1
        RJ=DBLE(FLOAT(J-1)/FLOAT(MRSCAL))
        if(j.gt.1) rj=1.0
        L=MRSCAL*(K-1)+J
	PSGAM(L,2)=(1.D0-RJ)*PSGAM(K,1) + RJ*PSGAM(K+1,1)
	DO 54 I=1,SOLS
   54   CSGAM(I,L,2)=(1.-RJ)*CSGAM(I,K,1) + RJ*CSGAM(I,K+1,1)
C
	LCHS(L)=PKC + DLOG10(CSGAM(4,L,2)/CSGAM(5,L,2))
	CSGAM(12,L,2)=10.**(-LCHS(L))
C
	TPS=CSGAM(7,L,2)+CSGAM(8,L,2)
	TNS=CSGAM(10,L,2)+CSGAM(11,L,2)
	TFS=CSGAM(13,L,2)+CSGAM(14,L,2)
C
	QPS=10.**(LCHS(L)-PKP)
	QNS=10.**(LCHS(L)-PKN)
	QFS=10.**(LCHS(L)-PKF)
C
	CSGAM(8,L,2)=TPS/(1.+QPS)
	CSGAM(7,L,2)=TPS-CSGAM(8,L,2)
	CSGAM(11,L,2)=TNS/(1.+QNS)
	CSGAM(10,L,2)=TNS-CSGAM(11,L,2)
	CSGAM(14,L,2)=TFS/(1.+QFS)
	CSGAM(13,L,2)=TFS-CSGAM(14,L,2)
C
	CSGAM(3,L,2)= CSGAM(1,L,2)*Z(1) + CSGAM(2,L,2)*Z(2)
	DO 55 I=4,SOLS
   55   CSGAM(3,L,2)=CSGAM(3,L,2)+CSGAM(I,L,2)*Z(I)
   56   CONTINUE
   58   CONTINUE
C
        DO 68 K=1,OMSLC(1)
        M=MRSLC(1)+1+K
        DO 66 J=1,OMSCAL+1
        RJ=DBLE(FLOAT(J-1)/FLOAT(OMSCAL))
        if(j.gt.1) rj=1.0
        L=MRSLC(2)+1+OMSCAL*(K-1)+J
	PSGAM(L,2)=(1.D0-RJ)*PSGAM(M,1) + RJ*PSGAM(M+1,1)
	DO 64 I=1,SOLS
   64   CSGAM(I,L,2)=(1.-RJ)*CSGAM(I,M,1) + RJ*CSGAM(I,M+1,1)
C
	LCHS(L)=PKC + DLOG10(CSGAM(4,L,2)/CSGAM(5,L,2))
	CSGAM(12,L,2)=10.**(-LCHS(L))
C
	TPS=CSGAM(7,L,2)+CSGAM(8,L,2)
	TNS=CSGAM(10,L,2)+CSGAM(11,L,2)
	TFS=CSGAM(13,L,2)+CSGAM(14,L,2)
C
	QPS=10.**(LCHS(L)-PKP)
	QNS=10.**(LCHS(L)-PKN)
	QFS=10.**(LCHS(L)-PKF)
C
	CSGAM(8,L,2)=TPS/(1.+QPS)
	CSGAM(7,L,2)=TPS-CSGAM(8,L,2)
	CSGAM(11,L,2)=TNS/(1.+QNS)
	CSGAM(10,L,2)=TNS-CSGAM(11,L,2)
	CSGAM(14,L,2)=TFS/(1.+QFS)
	CSGAM(13,L,2)=TFS-CSGAM(14,L,2)
C
	CSGAM(3,L,2)= CSGAM(1,L,2)*Z(1) + CSGAM(2,L,2)*Z(2)
	DO 65 I=4,SOLS
   65   CSGAM(3,L,2)=CSGAM(3,L,2)+CSGAM(I,L,2)*Z(I)
   66   CONTINUE
   68   CONTINUE
C
        DO 78 K=1,IMSLC(1)
        M=MRSLC(1)+1+OMSLC(1)+K
        DO 76 J=1,IMSCAL+1
        RJ=DBLE(FLOAT(J-1)/FLOAT(IMSCAL))
        if(j.gt.1) rj=1.0
        L=MRSLC(2)+1+OMSLC(2)+IMSCAL*(K-1)+J
	PSGAM(L,2)=(1.D0-RJ)*PSGAM(M,1) + RJ*PSGAM(M+1,1)
	DO 74 I=1,SOLS
   74   CSGAM(I,L,2)=(1.-RJ)*CSGAM(I,M,1) + RJ*CSGAM(I,M+1,1)
C
	LCHS(L)=PKC + DLOG10(CSGAM(4,L,2)/CSGAM(5,L,2))
	CSGAM(12,L,2)=10.**(-LCHS(L))
C
	TPS=CSGAM(7,L,2)+CSGAM(8,L,2)
	TNS=CSGAM(10,L,2)+CSGAM(11,L,2)
	TFS=CSGAM(13,L,2)+CSGAM(14,L,2)
C
	QPS=10.**(LCHS(L)-PKP)
	QNS=10.**(LCHS(L)-PKN)
	QFS=10.**(LCHS(L)-PKF)
C
	CSGAM(8,L,2)=TPS/(1.+QPS)
	CSGAM(7,L,2)=TPS-CSGAM(8,L,2)
	CSGAM(11,L,2)=TNS/(1.+QNS)
	CSGAM(10,L,2)=TNS-CSGAM(11,L,2)
	CSGAM(14,L,2)=TFS/(1.+QFS)
	CSGAM(13,L,2)=TFS-CSGAM(14,L,2)
C
	CSGAM(3,L,2)= CSGAM(1,L,2)*Z(1) + CSGAM(2,L,2)*Z(2)
	DO 75 I=4,SOLS
   75   CSGAM(3,L,2)=CSGAM(3,L,2)+CSGAM(I,L,2)*Z(I)
   76   CONTINUE
   78   CONTINUE
C
C	WRITE (303,30) OMSLC(2),IMSLC(2),MRSLC(2)
C
        GO TO 80
C FOR STEP INCREASES, RATHER THAN LINEAR:
        DO 92 K=5,SLICE(2)+1,2
        DO 92 J=1,SOLS
   92   CSGAM(J,K,2)=CSGAM(J,K+1,2)
C
   80   WRITE (303,28) (PSGAM(K,2),K=1,SLICE(2)+2)
        DO 82 J=1,11
   82   WRITE (303,28) (CSGAM(J,K,2),K=1,SLICE(2)+2)
        DO 84 J=13,15
   84   WRITE (303,28) (CSGAM(J,K,2),K=1,SLICE(2)+2)
C
        STOP
        END
