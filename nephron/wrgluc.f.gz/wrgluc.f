C 
      PROGRAM WRGLUC
C
C PROGRAM TO TAKE DATA GLUCOSE OUTPUT (STORED IN XY.GLUC) AND PREPARE IT
C  FOR GRAPHING BY grx.f.  
C THE INPUT IS CM(GLUC) AND FKM(GLUC) FOR PCT + PST, 
C  AND THEN CM(IMP) AND FKM(IMP) FOR THE REMAINDER OF THE NEPHRON.
C
 	DOUBLE PRECISION X(3000),Y(3000,50)
        INTEGER NCUR,NTAB,NVAL(300),NX
        CHARACTER*15  IPTFIL,OPTFIL
C 
C  X      - An array holding all X points for the graph
C  Y      - An array holding all Y points for the graph
C  NTAB   - Number of tables of data
C  NVAL   - Number of rows of data for each table
C  NX     - Total number of lines of data
C 
C*************************************************************************  
C
    4   FORMAT (A15)
	PRINT 2
    2   FORMAT(/,' PRINT THE INPUT FILENAME:',$)
	READ 4 , IPTFIL
        OPEN(1,FILE=IPTFIL)
	PRINT 6
    6   FORMAT(/,' PRINT THE OUTPUT FILENAME:',$)
	READ 4 , OPTFIL
        OPEN(2,FILE=OPTFIL)
C
	NCUR = 4
C--
   39   NX=0
	DO 40 NTAB=1,300
	READ (1,42,END=100) NVAL(NTAB)
        NVAL(NTAB) = NVAL(NTAB)+1
   42   FORMAT(I3)
	DO 44 I=1,NVAL(NTAB)
   44   READ (1,50) X(NX+I),(Y(NX+I,J),J=1,NCUR)
	NX=NX+NVAL(NTAB)
   40   CONTINUE
   50   FORMAT(8D16.8)
C
  100   NTAB=NTAB-1
C
        DO 110 I=1,NX
        Y(I,1) = Y(I,1) + Y(I,3)
        Y(I,2) = Y(I,2) + Y(I,4)
  110   CONTINUE
C
  139   NX=0
	DO 140 K=1,NTAB
	WRITE (2,42) NVAL(K)
	DO 144 I=1,NVAL(K)
  144   WRITE (2,50) X(NX+I),(Y(NX+I,J),J=1,2)
	NX=NX+NVAL(K)
  140   CONTINUE
C
        STOP
        END
